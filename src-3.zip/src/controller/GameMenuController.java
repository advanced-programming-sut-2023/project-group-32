package controller;

import model.Building;
import model.Troop;

public class GameMenuController {
    Building selectedBuilding;
    Troop selectedTroop;

    public void showPopularityFactors(){

    }
    public void showPopularity(){

    }
    public void showFoodList(){

    }
    public void changeFoodRate(int rateNumber){

    }
    public void showFoodRate(){

    }
    public void changeTaxRate(int rateNumber){

    }
    public void showTaxRate(){

    }
    public void changeFearRate(int rateNumber){

    }
    public void trade(String content){

    }
    public void tradeList(){

    }
    public void tradeHistory(){

    }

    public void dropBuilding(String content){

    }
    public void selectBuilding(int x , int y){

    }
    public void CreateUnit(String content){

    }
    public void repair(){

    }
    public void selectUnit(int x , int y){

    }
    public void moveUnit(int x , int y){

    }
    public void patrolUnit(String content){

    }
    public void set(String content){

    }
    public void attack(int x , int y){

    }
    public void attack(String enemy){

    }
    public void digTunnel(int x , int y){

    }
    public void pourOil(String direction){

    }
    public void disbandUnit() {

    }
    public void build(String equipmentName){

    }
}
