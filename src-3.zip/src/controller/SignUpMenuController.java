package controller;

import model.User;
import view.MainMenu;
import view.Menu;

import java.util.Objects;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignUpMenuController {

    public static void signUp(String content) throws InterruptedException {
        String username = getPart(content , "-u");
        String password = getPart(content , "-p");
        String nickName = getPart(content , "-n");
        String slogan = getPart(content , "-s");
        String email = getPart(content , "-e");
        String checkPassword = null;
        if(password != null)
            checkPassword = getPart(content, Modify(password));
        if(username == null) {
            System.out.println("You must have a username!");
            return;
        }
        if(password == null) {
            System.out.println("You must have a password!");
            return;
        }
        if(nickName == null) {
            System.out.println("You must have a nickname!");
            return;
        }
        if(email == null) {
            System.out.println("You must have an email!");
            return;
        }
        if(slogan == null && Pattern.compile("-s ").matcher(content).find()){
            System.out.println("Slogan is null!");
            return;
        }
        if(!username.matches("[\\w \t]+")){
            System.out.println("Incorrect format for username!");
            return;
        }
        if(User.getUserByUsername(username) != null){
            System.out.println("Username already exists!");
            System.out.println("You can set your username as: " + User.suggestUsername(username));
            return;
        }
        if(!password.equals("random") && (password.length() < 6 || !password.matches(".*[a-z].*") || !password.matches(".*[A-Z].*") ||
           !password.matches(".*[0-9].*") || !password.matches(".*[^a-zA-Z0-9].*"))){
            System.out.println("Your password is weak!");
            return;
        }
        if(!Objects.equals(checkPassword, password) && !password.equals("random")){

            System.out.println("Your password confirmation is not the same as your password!");
            return;
        }
        if(User.getUserByEmail(email) != null){
            System.out.println("Email already exists!");
            return;
        }
        if(!email.matches("[\\w.]+@[\\w.]+.[\\w.]+")){
            System.out.println("Incorrect format for Email!");
            return;
        }
        if(password.equals("random")){
            String randomPassword = randomPassword().substring(0 , 8);
            System.out.println("Your random password is: " + randomPassword);
            System.out.println("Please re-enter you password: ");
            password = randomPassword;
            if(Menu.checkPassword(randomPassword, "random", null))
                return;
        }
        if(slogan != null && slogan.equals("random")){
            int random = (int) Math.floor(Math.random() * 15);
            slogan = User.slogans[random];
            System.out.println("Your slogan: " + User.slogans[random]);
        }
        User user = new User(username , password , nickName , email , slogan);
        if(!Menu.securityQuestion(user))
            return;
        if (Controller.captcha())
            return;
        User.addUser(user);
        System.out.println("User created successfully!");
    }
    public static void login(String content) throws InterruptedException {
        String username = getPart(content , "-u");
        String password = getPart(content , "-p");
        if(username == null || password == null){
            System.out.println("You can't login without your username or password!");
            return;
        }
        if(User.getUserByUsername(username) == null){
            System.out.println("Username doesn't exist!");
            return;
        }
        User user = User.getUserByUsername(username);
        if(Menu.checkPassword(user.getPassword(), "login", password))
            return;
        if (Controller.captcha())
            return;
        System.out.println("User logged in successfully!");
        Menu.currentUser = User.getUserByUsername(username);
        MainMenu.run();
    }
    public static String randomPassword(){
            UUID randomUUID = UUID.randomUUID();
            return randomUUID.toString().replaceAll("-", "");
    }
    public static String getPart(String content , String mark){
        Matcher matcher = Pattern.compile(mark + "\\s+(?<firstWord>\\S+)").matcher(content);
        if(matcher.find()){
            String part = null;
            if(matcher.group("firstWord").charAt(0) == '\"'){
                matcher = Pattern.compile(mark + "\\s+\"(?<username>[^\"]+)\"").matcher(content);
                if(matcher.find())
                    part = matcher.group("username");
            }
            else
                part = matcher.group("firstWord");
            return part;
        }
        return null;
    }
    public static void forgotPassword(String content){
        String username = getPart(content , "-u");
        User user = User.getUserByUsername(username);
        if(user == null)
            System.out.println("Username does not exist!");
        else{
            System.out.println(User.securityQuestions[user.questionNumber]);
            Menu.checkAnswer(user);
        }
    }
    public static String Modify(String password){
        password = password.replaceAll("\\*" , "\\\\*");
        password = password.replaceAll("\\(" , "\\\\(");
        password = password.replaceAll("\\)" , "\\\\)");
        password = password.replaceAll("\\[" , "\\\\[");
        return password;
    }
}
