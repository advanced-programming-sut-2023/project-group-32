package controller;

import model.User;
import view.Menu;

import java.util.Scanner;

public class Controller {
    public static Scanner scanner = Menu.getScanner();
    public static int captchaGenerator(){
        String[] strings = new String[7];
        for(int i = 0 ; i < 7 ; i++){
            strings[i] = "";
        }
        int code = 0;
        int number;
        int random;
        int randomSize = (int) Math.floor(Math.random() * 4) + 4;
        for(int i = 0 ; i < randomSize ; i++){
            number = (int) Math.pow(10 , randomSize - 1 - i);
            random = (int) Math.floor(Math.random() * 10);
            code += number * random;
            Save(random , strings);
        }
        for(int i = 0 ; i < 7 ; i++){
            System.out.println(strings[i]);
        }
        return code;
    }
    public static boolean captcha(){
        String command;
        while (true){
            int code = captchaGenerator();
            command = scanner.nextLine();
            if(command.matches("[0-9]+")){
                if(Integer.parseInt(command) == code) {
                    System.out.println("Correct!");
                    return false;
                }
                else {
                    System.out.println("Wrong! If you want to make another captcha write \"again\", else you will quit captcha operation.");
                    if(scanner.nextLine().equals("again"))
                        continue;
                    else
                        return true;
                }
            }
            else {
                System.out.println("Wrong! If you want to make another captcha write \"again\", else you will quit captcha operation.");
                if (scanner.nextLine().equals("again"))
                    continue;
                else
                    return true;
            }
        }
    }
    public static void Save(int a , String[] strings){
        switch (a) {
            case 2 -> {
                strings[0] += "  ****    ";
                strings[1] += " *    *   ";
                strings[2] += "      *   ";
                strings[3] += "   ***    ";
                strings[4] += "  *       ";
                strings[5] += " *        ";
                strings[6] += " ******   ";
            }
            case 1 -> {
                strings[0] += "  *     ";
                strings[1] += " ***    ";
                strings[2] += "  **    ";
                strings[3] += "  **    ";
                strings[4] += "  **    ";
                strings[5] += "  *     ";
                strings[6] += " ****   ";
            }
            case 3 -> {
                strings[0] += "   ****    ";
                strings[1] += "      *    ";
                strings[2] += "      *    ";
                strings[3] += "   ***     ";
                strings[4] += "      *    ";
                strings[5] += "      *    ";
                strings[6] += "  ****     ";
            }
            case 4 -> {
                strings[0] += "     *    ";
                strings[1] += "   * *    ";
                strings[2] += "  *  *    ";
                strings[3] += "  *****   ";
                strings[4] += "     *    ";
                strings[5] += "     *    ";
                strings[6] += "     *    ";
            }
            case 5 -> {
                strings[0] += " ** ***    ";
                strings[1] += " *         ";
                strings[2] += "  *****    ";
                strings[3] += "       *   ";
                strings[4] += "       *   ";
                strings[5] += "  *    *   ";
                strings[6] += "   ****    ";
            }
            case 6 -> {
                strings[0] += " ****     ";
                strings[1] += " *        ";
                strings[2] += " *        ";
                strings[3] += " ******   ";
                strings[4] += " *    *   ";
                strings[5] += " *    *   ";
                strings[6] += "  ****    ";
            }
            case 7 -> {
                strings[0] += " *** **   ";
                strings[1] += "      *   ";
                strings[2] += "      *   ";
                strings[3] += "     *    ";
                strings[4] += "     *    ";
                strings[5] += "   *      ";
                strings[6] += "  *       ";
            }
            case 8 -> {
                strings[0] += " *****    ";
                strings[1] += " *    *   ";
                strings[2] += " *    *   ";
                strings[3] += "  ****    ";
                strings[4] += " *    *   ";
                strings[5] += " *    *   ";
                strings[6] += "  ****    ";
            }
            case 9 -> {
                strings[0] += "  ****    ";
                strings[1] += " *   *    ";
                strings[2] += "*    *    ";
                strings[3] += "  ****    ";
                strings[4] += "    *     ";
                strings[5] += "   *      ";
                strings[6] += "  *       ";
            }
            case 0 -> {
                strings[0] += "  ****    ";
                strings[1] += "*   **    ";
                strings[2] += " *  * *   ";
                strings[3] += " * *   *  ";
                strings[4] += " **   *   ";
                strings[5] += " *    *   ";
                strings[6] += "  *****   ";
            }
            default -> {
            }
        }
    }
    public static void setRank(){
        for(int i = 0; i < User.getUsers().size() - 1 ; i++){
            if(User.getUsers().get(i).getHighScore() < User.getUsers().get(i+1).getHighScore()){
                int t = User.getUsers().get(i).getRank();
                User.getUsers().get(i).setRank(User.getUsers().get(i+1).getRank());
                User.getUsers().get(i+1).setRank(t);
                i = -1;
            }
        }
    }
    public static void swap(User a, User b){
        int A = 0;
        int B = 0;
        for(int i = 0 ; i < User.getUsers().size() ; i++){
            if(User.getUsers().get(i) == a)
                A = i;
            if(User.getUsers().get(i) == b)
                B = i;
        }
        for(int i = 0 ; i < User.getUsers().size() ; i++){
            if(A < B && i == A){
                User.getUsers().remove(a);
                User.getUsers().add(A , b);
                User.getUsers().remove(b);
                User.getUsers().add(B , a);
                return;
            }
            else if(A > B && i == B){
                User.getUsers().remove(b);
                User.getUsers().add(B , a);
                User.getUsers().remove(a);
                User.getUsers().add(A , b);
                return;
            }
        }
    }
}
