package controller;

public class MapMenuController {
    public static void showMap(String content){

    }
    public static void shoowDetails(String content){

    }
    public void setTexture(String content){

    }
    public void clear(int x , int y){

    }
    public void dropRock(int x , int y , String direction){

    }
    public void dropTree(int x , int y , String type){

    }
    public void move(String content){

    }
}
