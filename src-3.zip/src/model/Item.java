package model;

public class Item {
    String name;
    String price;
    enum ItemType{Weapon, Material, Food};
    ItemType itemType;

    Item(String name, String price, ItemType itemType){
        this.name = name;
        this.price = price;
        this.itemType = itemType;
    }
}
