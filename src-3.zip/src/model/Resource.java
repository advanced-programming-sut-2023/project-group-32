package model;

public class Resource {
}
