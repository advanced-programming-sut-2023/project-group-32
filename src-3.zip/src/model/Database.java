package model;

public class Database {
    public void InitializeDatabase(){

    }
    private void InitializeItems(){

    }
    private void InitializeBuildings(){

    }
    private void InitializeTroops(){

    }
}
