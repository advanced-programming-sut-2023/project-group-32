package model;

import java.util.ArrayList;

public class Building {
    private int hp;
    ArrayList<InventorySlot> costs;
    String name;
    enum BuildingType{CastleBuilding, farms, foodProccess, industrial, cityBuildings, weaponBuilding};
    BuildingType buildingType;
    int requiredWorkers;
    int popularityRate;

    Building(int hp, ArrayList<InventorySlot> costs, String name, BuildingType buildingType, int requiredWorkers, int popularityRate){
        this.hp = hp;
        this.costs = costs;
        this.name = name;
        this.buildingType = buildingType;
        this.requiredWorkers = requiredWorkers;
        this.popularityRate = popularityRate;
    }
}
