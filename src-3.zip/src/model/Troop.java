package model;

import java.util.ArrayList;

public class Troop {
    String troopName;
    int price;
    ArrayList<Item> equipment;

    int attackPower, defencePower, speed;

    boolean mercenary;

    public Troop(String troopName, int price, ArrayList<Item> equipment, int attackPower, int defencePower, int speed, boolean mercenary) {
        this.troopName = troopName;
        this.price = price;
        this.equipment = equipment;
        this.attackPower = attackPower;
        this.defencePower = defencePower;
        this.speed = speed;
        this.mercenary = mercenary;
    }
}
