package model;

import java.util.ArrayList;

public class Tile {
    public ArrayList<Troop> troops;
    public Building building;
    public Resource resource;
    public String tileType;

    Tile(Resource resource, String tileType){
        building = null;
        troops = new ArrayList<>();

        this.tileType = tileType;
        this.resource = resource;
    }
}
