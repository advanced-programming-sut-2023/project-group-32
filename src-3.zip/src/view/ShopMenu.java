package view;

public class ShopMenu {
    public static void run(){

    }
}
