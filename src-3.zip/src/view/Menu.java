package view;

import model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Menu {
    public static User currentUser;
    private static final Scanner scanner = new Scanner(System.in);
    public static Scanner getScanner(){
        return scanner;
    }
    public static Matcher getMatcher(String command , String regex){
        Matcher matcher = Pattern.compile(regex).matcher(command);
        return matcher.matches() ? matcher : null;
    }
    public static boolean checkPassword(String realPassword , String condition , String enteredPassword) throws InterruptedException {
        int delayCounter = 5;
        if(enteredPassword == null)
            enteredPassword = scanner.nextLine();
        while (true) {
            if (enteredPassword.equals(realPassword)) {
                if(condition.equals("random"))
                    System.out.println("Your password set successfully!");
                return false;
            }
            if (enteredPassword.equals("cancel")) {
                System.out.println("The operation is canceled! Create your user again...!");
                return true;
            }
            else{
                System.out.println("Wrong password! Write you password again or if you want to cancel the operation type \"cancel\".");
                Thread.sleep(1000L * delayCounter);
                delayCounter += 5;
            }
            enteredPassword = scanner.nextLine();
        }
    }
    public static boolean securityQuestion(User user){
        String questionPickRegex = "\\s*question\\s+pick\\s+-q\\s+(?<number>[1-3])\\s+-a\\s+(?<answer>.+)\\s+-c\\s+(?<answerConfirmation>.+)\\s*";
        String command;
        Matcher matcher;
        System.out.println("Pick your security question:1.What is my father’s name?" +
                "  **  2.What was my first pet’s name?" +
                "  **  3.What is my mother’s last name?");
        while (true){
            command = scanner.nextLine();
            matcher = Pattern.compile(questionPickRegex)
                    .matcher(command);
            if(command.equals("cancel")){
                System.out.println("The operation is canceled!");
                return false;
            }
            else if(matcher.find()){
                if (!matcher.group("answer").equals(matcher.group("answerConfirmation"))) {
                    System.out.println("Answer confirmation is not same as your answer!");
                }
                else {
                    user.setSecurityQuestion(Integer.parseInt(matcher.group("number")) , matcher.group("answer"));
                    return true;
                }
            }
            else{
                System.out.println("Invalid command! If you want to cancel the operation type \"cancel\".");
            }
        }
    }
    public static void checkAnswer(User user){
        String command;
        while (true){
            command = scanner.nextLine();
            if(command.equals("cancel")) {
                System.out.println("The operation canceled!");
                return;
            }
            else if(command.equals(user.getQuestionAnswer())){
                System.out.println("Your password is: " + user.getPassword());
                return;
            }
            else
                System.out.println("Wrong answer! If you want to cancel the operation type \"cancel\".");
        }
    }
}