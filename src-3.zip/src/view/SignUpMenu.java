package view;

import controller.SignUpMenuController;

import java.util.regex.Matcher;

public class SignUpMenu {
    public static String createUserRegex = "^\\s*user\\s+create\\s+(?<content>.+)$";
    public static String loginUserRegex = "^\\s*user\\s+login\\s+(?<content>.+)$";
    public static String forgotPassword = "^\\s*forgot\\s+my\\s+password\\s+(?<content>.+)$";
    public static void run() throws InterruptedException {
        String command;
        Matcher matcher;
        while (true){
            command = Menu.getScanner().nextLine();
            if(command.matches("^\\s*exit\\s*$"))
                return;
            if((matcher = Menu.getMatcher(command , createUserRegex)) != null)
                SignUpMenuController.signUp(matcher.group("content"));
            else if((matcher = Menu.getMatcher(command , loginUserRegex)) != null)
                SignUpMenuController.login(matcher.group("content"));
            else if(command.matches("^\\s*show\\s+current\\s+menu$"))
                System.out.println("Signup Menu");
            else if((matcher = Menu.getMatcher(command , forgotPassword)) != null)
                SignUpMenuController.forgotPassword(matcher.group("content"));
            else
                System.out.println("Invalid command!");
        }
    }
}
