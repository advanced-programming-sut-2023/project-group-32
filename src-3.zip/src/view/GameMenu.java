package view;

public class GameMenu {
    public static void run(){

    }
}
