package view;

public class MapMenu {
    public void run(){

    }
}
