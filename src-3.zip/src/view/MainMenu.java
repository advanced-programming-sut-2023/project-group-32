package view;


public class MainMenu {
    public static void run() throws InterruptedException {
        String command;
        while (true){
            command = Menu.getScanner().nextLine();
            if(command.matches("^\\s*user\\s+logout\\s*$")) {
                System.out.println("User logout successfully!");
                Menu.currentUser = null;
                return;
            }
            else if(command.matches("^\\s*profile\\s+menu\\s*$")) {
                System.out.println("Entered Profile Menu!");
                ProfileMenu.run();
            }
            else if(command.matches("^\\s*map\\s+menu\\s*")){
                System.out.println("Entered Map Menu!");
                //MapMenu.run();
            }
            else if(command.matches("^\\s*show\\s+current\\s+menu\\s*$"))
                System.out.println("Main Menu");
            else
                System.out.println("Invalid command!");
        }
    }
}
