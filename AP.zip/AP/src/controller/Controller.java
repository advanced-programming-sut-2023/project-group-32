package controller;

import model.User;

import java.util.ArrayList;
import java.util.Objects;

public class Controller {
    public static ArrayList<User> Users = new ArrayList<>();

    public static User getUserByUsername(String username){
        for(User user : Users){
            if(Objects.equals(user.getUsername(), username)){
                return user;
            }
        }
        return null;
    }
    public static User getUserByEmail(String email){
        for(User user : Users){
            if(Objects.equals(user.getEmail(), email)){
                return user;
            }
        }
        return null;
    }
}
