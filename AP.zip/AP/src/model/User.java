package model;

public class User {
    private String username, password, nickname, email, slogan, securityQuestion, securityAnswer;

    public User(String username, String password, String email, String slogan){
        this.username = username;
        this.password = password;
        this.email = email;
        this.slogan = slogan;
    }

    public String getUsername(){
        return username;
    }
    public String getEmail(){
        return email;
    }
}
