package view;

public class LoginMenu {
}
