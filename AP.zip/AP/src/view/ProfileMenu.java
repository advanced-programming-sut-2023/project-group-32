package view;

public class ProfileMenu {
}
