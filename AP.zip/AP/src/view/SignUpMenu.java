package view;

import controller.Controller;
import model.User;

import java.util.Objects;
import java.util.regex.Matcher;

public class SignUpMenu {

    public String CreateUser(Matcher matcher){

        String username = matcher.group(1);
        String password = matcher.group(2);
        String passwordConfirm = matcher.group(3);
        String email = matcher.group(4);
        String slogan = matcher.group(5);

        if(!Objects.equals(passwordConfirm, password)){
            return "Password and Password Confirmation don't match";
        }

        if(!isValidPassword(password)){
            return "Password is Invalid";
        }
        if(!isValidUsername(username)){
            return "Username is Invalid";
        }
        if(Controller.getUserByUsername(username) != null){
            return "Username already exists";
        }
        if(Controller.getUserByEmail(email) != null){
            return "Email already exists";
        }
        if(isValidEmail(email)){
            return "Invalid Email";
        }

        User newUser = new User(username, password, email, slogan);
        Controller.Users.add(newUser);


        return "User Created Successfully";
    }

    static boolean isValidPassword(String password){
        return false;
    }
    static boolean isValidUsername(String username){
        return false;
    }
    static boolean isValidEmail(String emal){
        return false;
    }
}
