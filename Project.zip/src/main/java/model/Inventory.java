package model;

import java.util.ArrayList;
import java.util.Objects;

public class Inventory {

    public ArrayList<InventorySlot> Items;
    int capacity;

    Inventory(int capacity){
        this.capacity = capacity;
        Items = new ArrayList<>();
    }

    public void addItem(Item item, int amount){
        InventorySlot inventorySlot = new InventorySlot(item , amount);
        Items.add(inventorySlot);
    }
    public void addItem(String itemName, int amount){
        InventorySlot inventorySlot = new InventorySlot(Item.getItemByName(itemName) , amount);
        Items.add(inventorySlot);
    }
    public void removeItems(ArrayList<Item> items){
        for (InventorySlot item : Items) {
            for (Item item1 : items) {
                if(item.getItem().getName().equals(item1.name))
                    item.setAmount(item.getAmount() - 1);
            }
        }
    }
    public void addInventory(ArrayList<InventorySlot> inventorySlots){
        for (InventorySlot inventorySlot : inventorySlots) {
            addItem(inventorySlot.getItem() , inventorySlot.getAmount());
        }
    }
    public void removeInventory(ArrayList<InventorySlot> inventorySlots){
        for (InventorySlot inventorySlot : inventorySlots) {
            addItem(inventorySlot.getItem() , -inventorySlot.getAmount());
        }
    }
    public int getAmount(Item item){
        for(InventorySlot inventorySlot : Items){
            if(Objects.equals(inventorySlot.item, item)){
                return inventorySlot.getAmount();
            }
        }
        return 0;
    }
    public int getAmount(String itemName){
        for(InventorySlot inventorySlot : Items){
            if(Objects.equals(inventorySlot.item.getName(), itemName)){
                return inventorySlot.getAmount();
            }
        }
        return 0;
    }
    public boolean hasItems(ArrayList<Item> items){
        for(Item item : items){
            if(getAmount(item) == 0)
                return false;
        }
        return true;
    }
    public boolean hasInventory(ArrayList<InventorySlot> inventorySlots){

        for(InventorySlot inventorySlot : inventorySlots){
            if(getAmount(inventorySlot.item) < inventorySlot.amount)
                return false;
        }
        return true;
    }
}