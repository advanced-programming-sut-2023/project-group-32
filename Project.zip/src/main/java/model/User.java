package model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class User {
    private String username;
    private String password;
    private String nickName;
    private String email;
    public int questionNumber;
    private String questionAnswer;
    private int highScore;
    private int rank;
    private String slogan;
    private final Government government = new Government();

    public static String[] securityQuestions = new String[]{"What is my father’s name?",
            "What was my first pet’s name?",
            "What is my mother’s last name?"};
    public User(String username , String password , String nickName , String email , int highScore , int rank , int questionNumber , String questionAnswer , String slogan){
        this.username = username;
        this.password = password;
        this.nickName = nickName;
        this.email = email;
        this.slogan = slogan;
        this.rank = rank;
        this.highScore = highScore;
        this.questionNumber = questionNumber;
        this.questionAnswer = questionAnswer;
        government.setFoodRate(-2);
        government.setTaxRate(0);
        government.setPopulation(15);
        government.population = 20;
    }
    public String getPassword(){
        return password;
    }

    private static final ArrayList<User> users = new ArrayList<>();
    public static void addUser(User user) {
        users.add(user);
    }
    public static void addUserToFile(User user){
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try{
            FileWriter fileWriter = new FileWriter("players.json" , true);
            gson.toJson(user , fileWriter);
            fileWriter.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }
    public void setSecurityQuestion(int questionNum , String answer){
        this.questionAnswer = answer;
        this.questionNumber = questionNum - 1;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) throws IOException {
        this.username = username;
        Database.update();
    }
    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) throws IOException {
        this.nickName = nickName;
        Database.update();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws IOException {
        this.email = email;
        Database.update();
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) throws IOException {
        this.slogan = slogan;
        Database.update();
    }

    public static User getUserByUsername(String username){
        for (User user : users) {
            if(user.username.equals(username))
                return user;
        }
        return null;
    }
    public static User getUserByEmail(String email){
        for (User user : users) {
            if(user.email.equalsIgnoreCase(email))
                return user;
        }
        return null;
    }
    public static ArrayList<User> getUsers(){
        return users;
    }
    public static String suggestUsername(String username){
        int i = 1;
        String suggestingUsername;
        while (true){
            suggestingUsername = username + i;
            if(getUserByUsername(suggestingUsername) == null)
                return suggestingUsername;
            else
                i++;
        }
    }
    public void setPassword(String password) throws IOException {
        this.password = password;
        Database.update();
    }
    public String getQuestionAnswer(){
        return questionAnswer;
    }
    public int getHighScore(){
        return highScore;
    }
    public int getRank(){
        return rank;
    }
    public void setRank(int rank) throws IOException {
        this.rank = rank;
        Database.update();
    }

    public Government getGovernment() {
        return government;
    }
}