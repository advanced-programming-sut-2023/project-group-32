package view;

import controller.Controller;
import model.*;

import java.util.ArrayList;
import java.util.Objects;
import java.util.regex.Matcher;


public class TradeMenu {
    static int id = 1;
    public static void run(ArrayList<User> players , User currentPlayer){
        String command;
        Matcher matcher;
        for (String trade : GameMenu.trades) {
            if(Objects.equals(Controller.getPart(trade, "receiver:"), currentPlayer.getUsername()) || Objects.equals(Controller.getPart(trade, "sender:"), currentPlayer.getUsername()))
                System.out.println(trade);
        }
        while (true){
            command = Menu.getScanner().nextLine();
            if(command.matches("^\\s*show\\s+current\\s+menu\\s*$"))
                System.out.println("Trade Menu");
            else if(command.matches("^\\s*trade\\s+history\\s*$")){
                for (String trade : GameMenu.trades) {
                    if(Objects.equals(Controller.getPart(trade, "receiver:"), currentPlayer.getUsername()) || Objects.equals(Controller.getPart(trade, "sender:"), currentPlayer.getUsername()))
                        System.out.println(trade);
                }
            }
            else if(command.matches("^\\s*back\\s*$")){
                System.out.println("Exited Trade Menu!");
                return;
            }
            else if(command.matches("^\\s*show\\s+all\\s+players\\s*$")){
                int i = 1;
                for (User player : players) {
                    System.out.println(i + ") " + player.getUsername());
                    i++;
                }
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*trade\\s+-u\\s+(?<player>[\\s\\w]+)\\s+-t\\s+(?<type>\\S+)\\s+-a\\s+(?<amount>[-\\d]+)\\s+-p\\s+(?<price>[-\\d]+)\\s+-m\\s+(?<message>.+)\\s*$")) != null){
                String type = matcher.group("type");
                int amount = Integer.parseInt(matcher.group("amount"));
                int price = Integer.parseInt(matcher.group("price"));
                String message = matcher.group("message").trim();
                String player = matcher.group("player");
                trade(player , type , amount , price , message);
            }
            else if(command.matches("^\\s*trade\\s+list\\s*$")){
                for (String trade : GameMenu.trades) {
                    System.out.println(trade);
                }
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*trade\\s+accept\\s+-i\\s+(?<id>\\d+)\\s*$")) != null){
                String id = (matcher.group("id"));
                for (String trade : GameMenu.trades) {
                    if(Objects.requireNonNull(Controller.getPart(trade, "id:")).equals(id))
                        tradeAccept(trade);
                }
            }
            else
                System.out.println("Invalid command!");
        }
    }
    public static void trade(String user , String type , int amount , int price , String message){
        User receiver = User.getUserByUsername(user);
        if(receiver == null){
            System.out.println("No user with this name found!");
            return;
        }
        if(Item.getItemByName(type) == null){
            System.out.println("Invalid item!");
            return;
        }
        if(amount <= 0){
            System.out.println("Invalid amount!");
            return;
        }
        if(price < 0){
            System.out.println("Invalid price!");
            return;
        }
        Storage Stockpile = (Storage) Menu.currentUser.getGovernment().getBuildingByName("Stockpile");
        if(Stockpile == null){
            System.out.println("You don't have any Stockpile!");
            return;
        }
        for (InventorySlot item : Stockpile.getInventory().Items) {
            if(item.getItem().getName().equals(type)){
                if(item.getAmount() < amount){
                    System.out.println("You don't have enough " + type + " to trade!");
                    return;
                }
                else{
                    GameMenu.trades.add("sender: " + GameMenu.currentPLayer.getUsername() + " receiver: " + receiver.getUsername() + " type: " + type + " amount: " + amount + " price: " + price + " message: " + message + " id: " + id);
                    System.out.println("Your request sent!");
                    id++;
                }
            }
        }
        System.out.println("You don't have any " + type + "!");
    }
    public static void tradeAccept(String trade){
        User sender = User.getUserByUsername(Controller.getPart(trade , "sender:"));
        User receiver = User.getUserByUsername(Controller.getPart(trade , "receiver:"));
        int price = Integer.parseInt(Objects.requireNonNull(Controller.getPart(trade, "price:")));
        String type = Controller.getPart(trade , "type:");
        int amount = Integer.parseInt(Objects.requireNonNull(Controller.getPart(trade , "amount:")));
        for (Building building : Objects.requireNonNull(sender).getGovernment().getBuildings()) {
            if(building.getName().equals("Stockpile")){
                for (Building building1 : Objects.requireNonNull(receiver).getGovernment().getBuildings()) {
                    if(building1.getName().equals("Stockpile")){
                        Storage stockpile = (Storage) building;
                        Storage stockpile1 = (Storage) building1;
                        for (InventorySlot item : stockpile1.getInventory().Items) {
                            if(item.getItem().getName().equals("Gold")){
                                if(item.getAmount() - price < 0){
                                    System.out.println("You don't have enough gold to trade!");
                                    return;
                                }
                            }
                        }
                        for (InventorySlot item : stockpile1.getInventory().Items) {
                            if(item.getItem().getName().equals(type))
                                item.setAmount(item.getAmount() + amount);
                            if(item.getItem().getName().equals("Gold"))
                                item.setAmount(item.getAmount() - price);
                        }
                        for (InventorySlot item : stockpile.getInventory().Items) {
                            if(item.getItem().getName().equals("Gold"))
                                item.setAmount(item.getAmount() + price);
                            if(item.getItem().getName().equals(type))
                                item.setAmount(item.getAmount() - amount);
                        }
                        return;
                    }
                }
                System.out.println("The receiver doesn't have any Stockpile!");
                return;
            }
        }
        System.out.println("The sender doesn't have any Stockpile!");
    }
}
