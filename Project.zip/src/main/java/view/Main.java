package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import model.Database;

import java.io.IOException;
import java.net.URL;

public class Main extends Application {
    private static Stage stage;
    public static void main(String[] args) throws InterruptedException, IOException, CloneNotSupportedException {
        launch(args);
        Database.run();
        SignUpMenu.run();
    }

    @Override
    public void start(Stage stage) throws Exception {
        Main.stage=stage;
        URL url = Main.class.getResource("/FXML/main.fxml");
        BorderPane borderPane = FXMLLoader.load(url);
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }
}
