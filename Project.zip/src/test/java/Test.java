// Java Program to Print Colored Text in Console

// Importing input output classes
import controller.Controller;
import controller.ProfileMenuController;
import controller.SignUpMenuController;
import org.junit.Assert;
import view.messages.ProfileMenuMessages;
import view.messages.SignUpMenuMessages;


import java.io.*;

public class Test {

   @org.junit.Test
    public void loginTest() throws IOException, InterruptedException {
        Assert.assertEquals(SignUpMenuController.login("-u karbarJadid -p Password -n NICKNAME -e email@gmail.com") , SignUpMenuMessages.USERNAME_DOES_NOT_EXIST);
   }

    @org.junit.Test
    public void hashMakerTest(){
        Assert.assertEquals(Controller.hashMaker("Pass11!!") , "52ad23bdf087d7ba6f8f7085c5dca4e68fc85a6157d47a8f0d1951034d801ff7");
    }
    @org.junit.Test
    public void getPartTest(){
        Assert.assertEquals(Controller.getPart("-u username -p Password" , "-p") , "Password");
    }
    @org.junit.Test
    public void signUpTest() throws IOException, InterruptedException {
        Assert.assertEquals(SignUpMenuController.signUp("-u farhad -p Farhad1!! Farhad -n nick -e emailll@gmail.com") , SignUpMenuMessages.FAIL_PASSWORD_CONFIRMATION);
    }
    @org.junit.Test
    public void profileMenuTest() throws IOException {
       Assert.assertEquals(ProfileMenuController.change("-u user") , ProfileMenuMessages.USERNAME_CHANGED);
    }
    @org.junit.Test
    public void signUpTest2() throws IOException, InterruptedException {
       Assert.assertEquals(SignUpMenuController.signUp("-u user -p Pass Pass -n nick -e email@gmail.comm") , SignUpMenuMessages.WEAK_PASSWORD);
    }
    @org.junit.Test
    public void login2() throws IOException, InterruptedException {
       Assert.assertEquals(SignUpMenuController.login("-u karbar -p Pass") , SignUpMenuMessages.USERNAME_DOES_NOT_EXIST);
    }
}
