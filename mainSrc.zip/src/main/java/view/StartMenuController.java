package view;

import javafx.application.Platform;
import javafx.scene.input.MouseEvent;

public class StartMenuController {
    public void login() throws Exception {
        new LoginMenu().start(StartMenu.getStage());
    }

    public void signUp() throws Exception {
        new SignUpMenu().start(StartMenu.getStage());
    }

    public void quit() {
        Platform.exit();
    }
}
