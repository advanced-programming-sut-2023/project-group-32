package view;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client{
    final DataInputStream dataInputStream;
    final DataOutputStream dataOutputStream;


    public Client(String host, int port)  throws IOException {
        System.out.println("Starting Client service...");
        Socket socket = new Socket(host, port);
        dataInputStream = new DataInputStream(socket.getInputStream());
        dataOutputStream = new DataOutputStream(socket.getOutputStream());
        Input input = new Input(dataInputStream);
        input.start();
        Scanner scanner = new Scanner(System.in);
        handle(scanner);
    }


    private void handle(Scanner scanner) throws IOException {
        while (true) {
            String data = scanner.nextLine();
            dataOutputStream.writeUTF(data);
        }
    }
}
