package view;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.net.URL;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class QuestionMenu extends Application {
    private static Stage stage;
    @FXML
    private static String username;
    private static String password;
    private static String nickName;
    private static String email;
    private static String slogan;
    public static void setUser(String username , String password , String nickName , String email , String slogan){
        QuestionMenu.username = username;
        QuestionMenu.password = password;
        QuestionMenu.email = email;
        QuestionMenu.nickName = nickName;
        QuestionMenu.slogan = slogan;
    }


    @Override
    public void start(Stage stage) throws Exception {
        QuestionMenu.stage=stage;
        URL url = StartMenu.class.getResource("/FXML/questionMenu.fxml");
        Pane pane = FXMLLoader.load(url);
        // QUESTION
        ChoiceBox<String> choiceBox = new ChoiceBox<>();
        choiceBox.getItems().addAll("What is my father's name?" , "What was my first pet name?"
                , "What is my mother's last name?");
        choiceBox.setLayoutX(830); choiceBox.setLayoutY(320); choiceBox.setMinWidth(150);
        //choiceBox.setBackground(Background.fill(Color.DARKGREEN));
        choiceBox.setStyle("-fx-font-family: 'Sakkal Majalla'; -fx-font-size: 20px; -fx-text-fill: lawngreen;");
        TextField answer = new TextField(); answer.setPromptText("\t       answer");
        answer.setLayoutY(400); answer.setLayoutX(845); answer.setMinWidth(140);

        //CAPTCHA
        TextField captchaAnswer = new TextField(); captchaAnswer.setLayoutX(920); captchaAnswer.setLayoutY(600);
        captchaAnswer.setMaxWidth(55);
        AtomicInteger random = new AtomicInteger(Database.getRandomCaptcha());
        Rectangle captcha = new Rectangle(180 , 90); captcha.setFill(new ImagePattern(new Image
                (Objects.requireNonNull(QuestionMenu.class.getResource
                        ("/IMAGES/Captcha/" + random + ".png")).toExternalForm())));
        captcha.setLayoutX(860); captcha.setLayoutY(500);
        Button change = new Button("Change");
        change.setLayoutX(830); change.setLayoutY(650);



        //BACK AND CONFIRM
        Button back = new Button("Back"); back.setLayoutY(750); back.setLayoutX(990);
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new StartMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        Button confirm = new Button("Confirm");
        confirm.setLayoutY(back.getLayoutY()); confirm.setLayoutX(back.getLayoutX() - 280);

        pane.getChildren().addAll(back , captcha , answer , confirm , captchaAnswer , choiceBox , change);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        change.setOnMouseClicked(mouseEvent -> {
            int newRandom = changeCaptcha(pane, scene, stage);
            random.set(newRandom);
        });
        confirm.setOnMouseClicked(mouseEvent -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            String ans = answer.getText();
            int captchaNumber = Integer.parseInt(captchaAnswer.getText());
            if(ans == null || choiceBox.getSelectionModel().getSelectedItem() == null) {
                alert.setHeaderText("Failed singing up!");
                alert.setContentText("Choose question and answer correctly!");
                alert.show();
            }
            else if(captchaNumber != random.get()) {
                alert.setContentText("Wrong captcha!");
                alert.setHeaderText("Failed signing up!");
                alert.show();
                int newRandom = changeCaptcha(pane, scene, stage);
                random.set(newRandom);
            }
            else {
                alert.setAlertType(Alert.AlertType.CONFIRMATION);
                alert.setHeaderText("Success!");
                alert.setContentText("User signed up successfully!");
                User user = new User(username , password , nickName , email , 0 , 0 ,
                        choiceBox.getSelectionModel().getSelectedIndex() , answer.getText() , slogan , "/IMAGES/Avatars/tmp.png");
                User.addUser(user);
                //User.addUserToFile(user);
                alert.show();
                try {
                    new StartMenu().start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
    public int changeCaptcha(Pane pane, Scene scene, Stage stage) {
        int newRandom = Database.getRandomCaptcha();
        Rectangle captcha1 = new Rectangle(180 , 90);
        captcha1.setFill(new ImagePattern(new Image
                (Objects.requireNonNull(QuestionMenu.class.getResource
                        ("/IMAGES/Captcha/" + newRandom + ".png")).toExternalForm())));
        captcha1.setLayoutX(860);
        captcha1.setLayoutY(500);
        pane.getChildren().add(captcha1);
        scene.setRoot(pane);
        stage.setScene(scene);
        stage.show();
        return newRandom;
    }
    public Stage getStage(){
        return stage;
    }
}
