package view;

import controller.Controller;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class ProfileMenuController {
    @FXML
    public Label sloganLabel;
    @FXML
    public Text slogan;
    public Button removeSlogan;
    public Button addSlogan;
    public Button sloganButtonChange;
    @FXML
    private Text usernameText;
    @FXML
    private Text emailText;
    @FXML
    private Text nicknameText;
    @FXML
    private TextField usernameChange;
    @FXML
    private TextField emailChange;
    @FXML
    private TextField nicknameChange;
    @FXML
    private TextField sloganChange;
    @FXML
    private Button usernameConfirm;
    @FXML
    private Button emailConfirm;
    @FXML
    private Button sloganConfirm;
    @FXML
    private Button nicknameConfirm;
    @FXML
    private Text usernameError;
    @FXML
    private Text emailError;
    @FXML
    private Text nicknameError;
    public void initialize() throws IOException, InterruptedException, CloneNotSupportedException {
        usernameError.setFont(new Font(25));
        emailError.setFont(new Font(25));
        nicknameError.setFont(new Font(25));
        usernameText.setText(Menu.getCurrentUser().getUsername());
        emailText.setText(Menu.getCurrentUser().getEmail());
        nicknameText.setText(Menu.getCurrentUser().getNickName());
        setSlogan();
        usernameChange.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                usernameError.setText("You must have a username!");
            else if(!newText.matches("[\\w \t]+")) {
                usernameError.setText("Incorrect format for username!");
            }
            else if(User.getUserByUsername(newText) != null)
                usernameError.setText("Username already exists!");
            else
                usernameError.setText("");
        });
        emailChange.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                emailError.setText("You must have an email!");
            else if(!newText.matches("\\S+@\\S+\\.\\S+"))
                emailError.setText("Invalid format for email!");
            else if(User.getUserByEmail(newText) != null)
                emailError.setText("Email already exists~");
            else
                emailError.setText("");
        });
        nicknameChange.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                nicknameError.setText("You must have a nick name!");
            else
                nicknameError.setText("");
        });
    }
    public void back() throws Exception {
        new MainMenu().start(ProfileMenu.stage);
    }

    public void usernameChange(MouseEvent mouseEvent) {
        usernameChange.setVisible(true);
        usernameConfirm.setVisible(true);
        usernameError.setVisible(true);
    }

    public void passwordChange(MouseEvent mouseEvent) {
        showDialog();
    }
    public void emailChange(MouseEvent mouseEvent) {
        emailChange.setVisible(true);
        emailConfirm.setVisible(true);
        emailError.setVisible(true);
    }
    public void nicknameChange(MouseEvent mouseEvent) {
        nicknameChange.setVisible(true);
        nicknameConfirm.setVisible(true);
        nicknameError.setVisible(true);
    }

    public void usernameConfirm(MouseEvent mouseEvent) throws IOException {
        if(!usernameChange.getText().equals("") && usernameChange.getText().matches("[\\w \t]+") && User.getUserByUsername(usernameChange.getText()) == null){
            usernameChange.setVisible(false);
            usernameConfirm.setVisible(false);
            usernameError.setVisible(false);
            Menu.getCurrentUser().setUsername(usernameChange.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("success");
            alert.setContentText("your username changed successfully");
            alert.show();
            usernameText.setText(Menu.getCurrentUser().getUsername());
        }
    }

    public void emailConfirm(MouseEvent mouseEvent) throws IOException {
        if(!emailChange.getText().equals("") && emailChange.getText().matches("\\S+@\\S+\\.\\S+") && User.getUserByEmail(emailChange.getText()) == null){
            emailChange.setVisible(false);
            emailConfirm.setVisible(false);
            emailError.setVisible(false);
            Menu.getCurrentUser().setEmail(emailChange.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("success");
            alert.setContentText("your email changed successfully");
            alert.show();
            emailText.setText(Menu.getCurrentUser().getEmail());
        }
    }

    public void nicknameConfirm(MouseEvent mouseEvent) throws IOException {
        if(!nicknameChange.getText().equals("")){
            nicknameChange.setVisible(false);
            nicknameConfirm.setVisible(false);
            nicknameError.setVisible(false);
            Menu.getCurrentUser().setNickName(nicknameChange.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("success");
            alert.setContentText("your nickname changed successfully");
            alert.show();
            nicknameText.setText(Menu.getCurrentUser().getNickName());
        }
    }
    private void showDialog() {
        AtomicInteger answer = new AtomicInteger();
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Password Dialog");
        dialog.setHeaderText("Please enter your passwords");

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, cancelButton);

        PasswordField oldPassword = new PasswordField();
        PasswordField newPassword = new PasswordField();

        TextField captchaAnswer = new TextField();
        AtomicInteger random = new AtomicInteger(Database.getRandomCaptcha());
        Rectangle captcha = new Rectangle(120 , 80); captcha.setFill(new ImagePattern(new Image
                (Objects.requireNonNull(QuestionMenu.class.getResource
                        ("/IMAGES/Captcha/" + random + ".png")).toExternalForm())));
        answer = random;
        Text oldPasswordError = new Text();
        Text newPasswordError = new Text();
        oldPasswordError.setText("Wrong password!");
        newPasswordError.setText("You must have a password!");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);
        grid.addRow(0, new Label("old password:"), oldPassword , oldPasswordError);
        grid.addRow(1, new Label("new password:"), newPassword , newPasswordError);
        grid.addRow(2 , captcha , captchaAnswer);
        dialog.getDialogPane().setContent(grid);

        dialog.getDialogPane().setPrefWidth(500);
        dialog.getDialogPane().setPrefHeight(250);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButton) {
                return ButtonType.OK;
            }
            return ButtonType.CANCEL;
        });
        oldPassword.textProperty().addListener((observable, oldText, newText)->{
            if(!newText.equals(Menu.getCurrentUser().getPassword()))
                oldPasswordError.setText("Wrong password!");
            else
                oldPasswordError.setText("");
        });

        newPassword.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                newPasswordError.setText("You must have a password!");
            else if(!Controller.checkPassword(newText))
                newPasswordError.setText("Your password is weak!");
            else
                newPasswordError.setText("");
        });

        AtomicInteger finalAnswer = answer;
        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK && captchaAnswer.getText().matches("\\d+")) {
                String password1 = oldPassword.getText();
                String password2 = newPassword.getText();
                int number = Integer.parseInt(captchaAnswer.getText());
                if (password1.equals(Menu.getCurrentUser().getPassword()) && Controller.checkPassword(password2) && number == finalAnswer.get()) {
                    try {
                        Menu.getCurrentUser().setPassword(password2);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information Dialog");
                    alert.setHeaderText(null);
                    alert.setContentText("Passwords changed!");
                    alert.showAndWait();
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Changing password failed!");
                alert.setContentText("Incorrect passwords or captcha!");
                alert.show();
            }
        });
    }

    public void sloganChange(MouseEvent mouseEvent) {
        sloganChange.setVisible(true);
        sloganConfirm.setVisible(true);
    }
    public void newSlogan() throws IOException {
        if(!sloganChange.getText().equals("")){
            sloganChange.setVisible(false);
            sloganConfirm.setVisible(false);
            Menu.getCurrentUser().setSlogan(sloganChange.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText("success");
            alert.setContentText("your slogan changed successfully");
            alert.show();
            setSlogan();
        }
    }

    private void setSlogan() {
        if(Menu.currentUser.getSlogan() != null) {
            StringBuilder slogan = new StringBuilder(Menu.currentUser.getSlogan());
            int words = 0;
            for (int i = 0; i < Menu.currentUser.getSlogan().length(); i++) {
                if (slogan.charAt(i) == ' ')
                    words++;
                if (words == 13) {
                    slogan.insert(i, "\n");
                    words = 0;
                }
            }
            sloganLabel.setText(slogan.toString());
        }
    }

    public void removeSlogan(MouseEvent mouseEvent) throws IOException {
        sloganChange.setVisible(false);
        sloganConfirm.setVisible(false);
        sloganLabel.setVisible(false);
        sloganButtonChange.setVisible(false);
        slogan.setVisible(false);
        removeSlogan.setVisible(false);
        addSlogan.setVisible(true);

        Menu.getCurrentUser().setSlogan(null);
    }
    public void addSlogan() {
        sloganChange.setVisible(false);
        //sloganConfirm.setVisible(true);
        sloganLabel.setText(null);
        sloganLabel.setVisible(true);
        sloganButtonChange.setVisible(true);
        slogan.setVisible(true);
        removeSlogan.setVisible(true);
        addSlogan.setVisible(false);
    }
}
