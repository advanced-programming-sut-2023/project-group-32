package view;

public class ShopMenu2Controller {
}
