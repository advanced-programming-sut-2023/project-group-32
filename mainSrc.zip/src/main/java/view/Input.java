package view;

import java.io.DataInputStream;
import java.io.IOException;

public class Input extends Thread{
    private final DataInputStream dataInputStream;

    public Input(DataInputStream dataInputStream) {
        this.dataInputStream = dataInputStream;
    }

    @Override
    public synchronized void run() {
        try {
            while (true) {
                String data = dataInputStream.readUTF();
                if(!data.startsWith("{"))
                    System.out.println(data);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
