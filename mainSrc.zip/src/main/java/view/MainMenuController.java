package view;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class MainMenuController {
    public void profileMenu() throws Exception {
        new ProfileMenu().start(MainMenu.stage);
    }
    public void back() throws Exception {
        new StartMenu().start(MainMenu.stage);
    }
    public void startGame() throws Exception {
        new GameMaker().start(MainMenu.stage);
    }

    public void scoreBoard() throws Exception {
        Scoreboard scoreboard = new Scoreboard();
        scoreboard.setPage(1);
        scoreboard.start(MainMenu.stage);
    }

    public void start() {
        //new GameMenu(players).start(MainMenu.stage);
    }
}