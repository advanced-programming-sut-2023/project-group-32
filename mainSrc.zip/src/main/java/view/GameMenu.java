package view;

import com.example.apmap.HelloController;
import controller.GameMenuController;
import controller.MapMenuController;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import model.Database;
import model.Government;
import model.Map;
import model.User;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
public class GameMenu extends Application {
    int turnsCount;

    static ArrayList<User> players = new ArrayList<>();
    static User currentPLayer;
    static User host;
    static Map map;
    static Stage stage;
    public static ArrayList<String> trades = new ArrayList<>();
    public void setPlayers(ArrayList<User> players) {
        this.turnsCount = 30;
        GameMenu.host = Menu.currentUser;
        GameMenu.map = new Map();
        GameMenuController.gameMap = map;
        GameMenu.players = players;
    }
    /*public GameMenu(ArrayList<User> players){
        this.turnsCount = 30;
        GameMenu.players = players;
        GameMenu.host = Menu.currentUser;
        GameMenu.map = new Map();
        GameMenuController.gameMap = map;
    }*/
    public void run() throws CloneNotSupportedException, IOException {
        String validGame = Menu.setColours(players , Database.colours);
        if(validGame.equals("FAIL"))
            return;
        validGame = Menu.setHeadquarters(players , map);
        if(validGame.equals("FAIL"))
            return;
        String command;
        Matcher matcher;
        System.out.println("The game started!");
        GameMenuController.Players = new Government[players.size()];

        for(int i = 0; i < players.size(); i++){
            GameMenuController.Players[i] = players.get(i).getGovernment();
        }
        currentPLayer = host;
        GameMenuController.currentGovernment = currentPLayer.getGovernment();
        GameMenuController.currentGovernment.setUser(currentPLayer);
        int counter = 0;
        while (true){
            command = Menu.getScanner().nextLine();
            if(command.matches("^\\s*show\\s+current\\s+player\\s*$"))
                System.out.println(currentPLayer.getUsername() + " is now playing!");
            else if(command.matches("^\\s*show\\s+current\\s+menu\\s*$"))
                System.out.println("Game Menu");
            else if(command.matches("^\\s*show\\s+turns\\s+left\\s*$"))
                System.out.println((turnsCount - counter) + " turns left!");
            else if(command.matches("^\\s*show\\s+my\\s+colour\\s*"))
                System.out.println(currentPLayer.getGovernment().getColour());
            else if(command.matches("^\\s*next\\s+turn\\s*$")){
                GameMenuController.nextTurn();
                /*int i = players.indexOf(currentPLayer);
                int j = (i+1)%players.size();
                currentPLayer = players.get(j);
                GameMenuController.currentGovernment = currentPLayer.getGovernment();
                GameMenuController.nextTurn();
                System.out.println("User " + currentPLayer.getUsername() + " is now playing!");
                if(j == 0)
                    counter++;
                if(counter == turnsCount){
                    System.out.println("The game has ended...!");
                    return;
                }*/
            }
            else if(command.matches("^\\s*show\\s+all\\s+players\\s*$")){
                int n = 1;
                for (User player : players) {
                    System.out.println(n + ") " + player.getUsername());
                    n++;
                }
            }
            else if(command.matches("^\\s*map\\s+menu\\s*$")){
                System.out.println("Entered Map Menu!");
                MapMenu.run(map);
            }
            else if(command.matches("^\\s*trade\\s+menu\\s*$")) {
                System.out.println("Entered Trade Menu!");
                TradeMenu.run(players , currentPLayer);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*set\\s+texture\\s+(?<content>.+)\\s*$")) != null){
                String content = matcher.group("content");
                MapMenuController.setTexture(content , map);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*clear\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s*$")) != null) {
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                MapMenuController.clear(x , y);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*drop\\s+rock\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s+-d\\s+(?<direction>[wsne])\\s*")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                String direction = matcher.group("direction");
                GameMenuController.dropRock(x , y , direction);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*drop\\s+tree\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s+-t\\s+(?<type>\\S+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                String type = matcher.group("type");
                GameMenuController.dropTree(x , y , type);
            }
            else if(command.matches("^\\s*show\\s+popularity\\s+factors\\s*$"))
                GameMenuController.showPopularityFactors();
            else if(command.matches("^\\s*show\\s+popularity\\s*$"))
                GameMenuController.showPopularity();
            else if((matcher = Menu.getMatcher(command , "^\\s*food\\s+rate\\s+-r\\s+(?<rate>[-\\d]+)\\s*")) != null) {
                int rate = Integer.parseInt(matcher.group("rate"));
                System.out.println("Updated food rate");
                if(rate > 2 || rate < -2)
                    System.out.println("Invalid rate!");
                else
                    currentPLayer.getGovernment().setFoodRate(Integer.parseInt(matcher.group("rate")));
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*fear\\s+rate\\s+-r\\s+(?<rate>[-\\d]+)\\s*")) != null) {
                int rate = Integer.parseInt(matcher.group("rate"));
                System.out.println("updated fear rate");
                if(rate > 5 || rate < -5)
                    System.out.println("Invalid rate!");
                else
                    currentPLayer.getGovernment().setFearRate(Integer.parseInt(matcher.group("rate")));
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*tax\\s+rate\\s+-r\\s+(?<rate>[-\\d]+)\\s*")) != null) {
                int rate = Integer.parseInt(matcher.group("rate"));
                System.out.println("updated stax rate");
                if(rate < -3 || rate > 8)
                    System.out.println("Invalid rate");
                else
                    currentPLayer.getGovernment().setTaxRate(Integer.parseInt(matcher.group("rate")));
            }
            else if(command.matches("^\\s*show\\s+food\\s+list\\s*$"))
                GameMenuController.showFoodList();
            else if(command.matches("^\\s*food\\s+rate\\s+show\\s*$"))
                System.out.println(currentPLayer.getGovernment().getFoodRate());
            else if(command.matches("^\\s*tax\\s+rate\\s+show\\s*$"))
                System.out.println(currentPLayer.getGovernment().getTaxRate());
            else if(command.matches("^\\s*fear\\s+rate\\s+show\\s*"))
                System.out.println(currentPLayer.getGovernment().getFearRate());
            else if((matcher = Menu.getMatcher(command , "^\\s*drop\\s+building\\s+-x\\s+(?<x>(-)?\\d+)\\s+-y\\s+(?<y>(-)?\\d+)\\s+-t\\s+(?<type>.+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                String type = matcher.group("type").trim();
                GameMenuController.dropBuilding(x , y , type);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*select\\s+building\\s+-x\\s+(?<x>(-)?\\d+)\\s+-y\\s+(?<y>(-)?\\d+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                GameMenuController.selectBuilding(x , y);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*create\\s+unit\\s+-t\\s+(?<type>\\S+)\\s+-c\\s+(?<count>\\d+)\\s*$")) != null){
                String type = matcher.group("type");
                int count = Integer.parseInt(matcher.group("count"));
                GameMenuController.CreateUnit(type , count);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*drop\\s+unit\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s+-t\\s+(?<type>\\S+)\\s+-c\\s+(?<count>\\d+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                String type = matcher.group("type");
                int count = Integer.parseInt(matcher.group("count"));
                GameMenuController.DropUnit(type , count , x , y);
            }
            else if(command.matches("^\\s*show\\s+selected\\s+building\\s*$")) {
                if(GameMenuController.selectedBuilding == null)
                    System.out.println("No building is selected!");
                else
                    System.out.println("Name: " + GameMenuController.selectedBuilding.getName() + " | Owner: " + GameMenuController.selectedBuilding.getOwner().getUser().getUsername());
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*select\\s+unit\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                GameMenuController.selectUnit(x , y);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*move\\s+unit\\s+to\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                GameMenuController.moveUnit(x , y);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*patrol\\s+unit\\s+-x1\\s+(?<x1>\\d+)\\s+-y1\\s+(?<y1>\\d+)\\s+-x2\\s+(?<x2>\\d+)\\s+-y2\\s+(?<y2>\\d+)\\s*$")) != null){
                int x1 = Integer.parseInt(matcher.group("x1"));
                int x2 = Integer.parseInt(matcher.group("x2"));
                int y1 = Integer.parseInt(matcher.group("y1"));
                int y2 = Integer.parseInt(matcher.group("y2"));
                GameMenuController.patrolUnit(x1 , y1 , x2 , y2);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*attack\\s+-e\\s+(?<enemy>.+)\\s*$")) != null){
                String enemy = matcher.group("enemy").trim();
                GameMenuController.attack(enemy);
            }
            else if(command.matches("^\\s*disband\\s+unit\\s*$"))
                GameMenuController.disbandUnit();
            else if((matcher = Menu.getMatcher(command , "^\\s*set\\s+-x\\s+(?<x>\\d+)\\s+-y\\s+(?<y>\\d+)\\s+-s\\s+(?<state>\\S+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                String state = matcher.group("state");
                GameMenuController.set(x , y , state);
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*attack\\s+-e\\s+(?<x>\\d+)\\s+(?<y>\\d+)\\s*$")) != null){
                int x = Integer.parseInt(matcher.group("x"));
                int y = Integer.parseInt(matcher.group("y"));
                GameMenuController.attack(x , y);
            }
            else if(command.matches("^\\s*show\\s+price\\s+list\\s*$")) {
                if(GameMenuController.selectedBuilding.getName().equals("Market"))
                    GameMenuController.showPriceList();
                else
                    System.out.println("You didn't select the market!");
            }
            else if((matcher = Menu.getMatcher(command , "^\\s*buy\\s+-i\\s+(?<name>\\S+)\\s+-a\\s+(?<amount>\\d+)\\s*$")) != null){
                if(GameMenuController.selectedBuilding.getName().equals("Market")) {
                    String name = matcher.group("name");
                    int amount = Integer.parseInt(matcher.group("amount"));
                    GameMenuController.buy(name, amount);
                }
                else
                    System.out.println("You didn't select the market!");
            }
            else if(command.matches("^\\s*repair\\s*$"))
                GameMenuController.repair();
            else if((matcher = Menu.getMatcher(command , "^\\s*sell\\s-i\\s+(?<name>\\S+)\\s+-a\\s+(?<amount>\\d+)\\s*$")) != null){
                if(GameMenuController.selectedBuilding.getName().equals("Market")) {
                    String name = matcher.group("name");
                    int amount = Integer.parseInt(matcher.group("amount"));
                    GameMenuController.sell(name, amount);
                }
                else
                    System.out.println("You didn't select the market!");
            }
            else
                System.out.println("Invalid command!");
        }
    }


    // BARBI ENTERED:

    private static final int GRID_SIZE = 200;
    private static final int VISIBLE_SIZE = 30;
    private static final int CELL_SIZE = 60;

    private GridPane gridPane;
    private StackPane stackPane;
    private Circle buildingImage;
    private double startX, startY;
    private float mouseSensitivity = 5f;
    private Boolean inBuilding = false;

    @Override
    public void start(Stage primaryStage) throws IOException {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/COM/hello-view.fxml"));
        Scene scene = new Scene(loader.load());

        com.example.apmap.HelloController controller = loader.getController();
        controller.Awake();
        controller.scene = scene;

        scene.setOnMousePressed(controller::handleMousePressed);
        scene.setOnMouseDragged(controller::handleMouseDragged);

        primaryStage.setScene(scene);
        primaryStage.show();
        centerStage(primaryStage);
    }
    public static void centerStage(Stage stage) {
        // Get the primary screen bounds
        javafx.geometry.Rectangle2D screenBounds = javafx.stage.Screen.getPrimary().getVisualBounds();

        // Calculate the position to center the stage
        double centerX = screenBounds.getMinX() + (screenBounds.getWidth() - stage.getWidth()) / 2;
        double centerY = screenBounds.getMinY() + (screenBounds.getHeight() - stage.getHeight()) / 2;

        // Set the stage position
        stage.setX(centerX);
        stage.setY(centerY);
    }

    private StackPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(1);
        gridPane.setVgap(1);

        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                Rectangle rect = new Rectangle(CELL_SIZE, CELL_SIZE, Color.WHITE);
                rect.setStroke(Color.LIGHTGRAY);

                Text text = new Text(col + "," + row);

                text.setFill(Color.BLACK);
                text.setVisible(false);

                StackPane stackPane = new StackPane(rect, text);
                stackPane.setAlignment(Pos.CENTER);

                final int currentCol = col;
                final int currentRow = row;

                stackPane.setOnMouseEntered(event -> handleMouseEnter(currentCol, currentRow));
                stackPane.setOnMouseExited(event -> handleMouseExit(currentCol, currentRow));
                stackPane.setOnMouseClicked(event -> handleMouseClicked(currentCol, currentRow));

                gridPane.add(stackPane, col, row);
            }
        }
        Circle circle = new Circle();
        circle.setRadius(10);
        circle.setVisible(false);

        gridPane.getChildren().add(circle);

        gridPane.setOnMouseMoved(event -> {
            circle.setTranslateX(event.getX() - circle.getRadius() / 2);
            circle.setTranslateY(event.getY() - circle.getRadius() * 2);
        });
        gridPane.setOnScroll(event -> {
            double deltaY = event.getDeltaY();
            double zoomFactor = 1.05;

            if (deltaY < 0) {
                zoomFactor = 1 / zoomFactor;
            }

            gridPane.setScaleX(gridPane.getScaleX() * zoomFactor);
            gridPane.setScaleY(gridPane.getScaleY() * zoomFactor);

            event.consume();
        });

        this.buildingImage = circle;
        this.gridPane = gridPane;

        Button button = new Button("Build");
        Button shop = new Button("Shop");
        Button exit = new Button("Exit");
        Button trade = new Button("Trade Menu");
        button.setPrefWidth(100); exit.setPrefWidth(100);
        button.setPrefHeight(40); exit.setPrefHeight(40);

        button.setOnMouseClicked(event -> {
            this.buildingImage.setVisible(true);
            inBuilding = true;
        });
        exit.setOnMouseClicked(mouseEvent -> {
            try {
                new MainMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        shop.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                // newShopMenu...
            }
        });
        trade.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    Stage newStage = new Stage();
                    new TradeMenu().start(newStage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        StackPane root = new StackPane();
        root.getChildren().addAll(gridPane, button , exit , shop , trade);
        StackPane.setAlignment(button, Pos.BOTTOM_CENTER);
        StackPane.setAlignment(exit , Pos.BOTTOM_LEFT);
        StackPane.setAlignment(shop , Pos.TOP_CENTER);
        StackPane.setAlignment(trade , Pos.BOTTOM_RIGHT);
        button.setTextAlignment(TextAlignment.CENTER);
        exit.setTextAlignment(TextAlignment.CENTER);
        shop.setTextAlignment(TextAlignment.CENTER);
        trade.setTextAlignment(TextAlignment.CENTER);
        return root;
    }
    private void handleMouseClicked(int col, int row){
        if(!inBuilding) return;

        Circle circle = new Circle();
        circle.setRadius(10);
        circle.setVisible(true);

        circle.setFill(Color.RED);

        gridPane.getChildren().add(circle);

        Rectangle rect = getRectangleByCoordinates(col, row);
        if(rect == null) return;

        circle.setTranslateX(buildingImage.getTranslateX());
        circle.setTranslateY(buildingImage.getTranslateY());

        buildingImage.setVisible(false);
        inBuilding = false;
    }
    private void handleMouseEnter(int col, int row) {
        /*Rectangle rect = getRectangleByCoordinates(col, row);
        if (rect != null) {
            Text text = (Text) ((StackPane) rect.getParent()).getChildren().get(1);
            text.setVisible(true);
        }*/
    }

    private void handleMouseExit(int col, int row) {
        /*Rectangle rect = getRectangleByCoordinates(col, row);
        if (rect != null) {
            Text text = (Text) ((StackPane) rect.getParent()).getChildren().get(1);
            text.setVisible(false);
        }*/
    }

    private void handleMousePressed(MouseEvent event) {
        startX = event.getSceneX();
        startY = event.getSceneY();
    }

    private void handleMouseDragged(MouseEvent event) {
        if (event.getButton() == MouseButton.PRIMARY) {
            double deltaX = event.getSceneX() - startX;
            double deltaY = event.getSceneY() - startY;

            double translateX = deltaX / CELL_SIZE;
            double translateY = deltaY / CELL_SIZE;

            gridPane.setTranslateX(gridPane.getTranslateX() + translateX * mouseSensitivity);
            gridPane.setTranslateY(gridPane.getTranslateY() + translateY * mouseSensitivity);

            startX = event.getSceneX();
            startY = event.getSceneY();
        }
    }
    private Rectangle getRectangleByCoordinates(int x, int y) {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof StackPane) {
                StackPane stackPane = (StackPane) node;
                int col = GridPane.getColumnIndex(stackPane);
                int row = GridPane.getRowIndex(stackPane);
                if (col == x && row == y) {
                    return (Rectangle) stackPane.getChildren().get(0);
                }
            }
        }
        return null; // Return null if the rectangle is not found
    }
}
