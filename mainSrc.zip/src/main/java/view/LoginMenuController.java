package view;

import controller.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import model.Database;
import model.User;

import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class LoginMenuController {
    @FXML
    public TextField captchaAnswer;
    @FXML
    private TextField username;
    @FXML
    private Text usernameError;
    @FXML
    private PasswordField password;
    @FXML
    private Text passwordError;
    @FXML
    private TextField visiblePassword;
    @FXML
    private CheckBox visiblePasswordCheckBox;
    @FXML
    private Text recoveryQuestion;
    @FXML
    private TextField recoveryAnswer;
    @FXML
    private Button securityAnswerButton;
    @FXML
    private PasswordField newPassword;
    @FXML
    private TextField visibleNewPassword;
    @FXML
    private CheckBox visibleNewPasswordCheckBox;
    @FXML
    private Button setNewPasswordButton;
    @FXML
    private Text newPasswordError;
    @FXML
    private Text securityAnswerError;
    public void initialize() {
        recoveryQuestion.setFont(new Font(18));
        newPasswordError.setFont(new Font(13));
        securityAnswerError.setFont(new Font(13));
        password.textProperty().addListener((observable, oldText, newText)->{
            visiblePassword.setText(newText);
        });
        visiblePassword.textProperty().addListener((observable, oldText, newText)->{
            password.setText(newText);
        });
        newPassword.textProperty().addListener((observable, oldText, newText)->{
            visibleNewPassword.setText(newText);
        });
        visibleNewPassword.textProperty().addListener((observable, oldText, newText)->{
            newPassword.setText(newText);
        });
        newPassword.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                newPasswordError.setText("You must have a password!");
            else if(!Controller.checkPassword(newText))
                newPasswordError.setText("Your password is weak!");
            else
                newPasswordError.setText("");
        });
    }
    public void passwordRecovery() {
        if(User.getUserByUsername(username.getText()) == null){
            usernameError.setVisible(true);
        }
        else {
        usernameError.setVisible(false);
        recoveryQuestion.setVisible(true);
        recoveryQuestion.setText(Database.questions[Objects.requireNonNull
                (User.getUserByUsername(username.getText())).getQuestionNumber()]);
        recoveryAnswer.setVisible(true);
        securityAnswerButton.setVisible(true);
        }
    }
    public void confirm() {
        if(recoveryAnswer.getText().equals(Objects.requireNonNull
                (User.getUserByUsername(username.getText())).getQuestionAnswer())) {
            newPassword.setVisible(true);
            visibleNewPasswordCheckBox.setVisible(true);
            setNewPasswordButton.setVisible(true);
            newPasswordError.setVisible(true);
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Failed setting new password!");
            alert.setContentText("Wrong answer!");
            alert.show();
        }
    }
    public void enter() throws Exception {
        if(User.getUserByUsername(username.getText()) == null) {
            usernameError.setVisible(true);
            changeCaptcha();
        }
        else if(!Objects.requireNonNull(User.getUserByUsername
                (username.getText())).getPassword().equals(password.getText())){
            usernameError.setVisible(false);
            passwordError.setVisible(true);
            changeCaptcha();
        }
        else if(!captchaAnswer.getText().equals(String.valueOf(LoginMenu.captcha))) {
            usernameError.setVisible(false);
            passwordError.setVisible(false);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Login failed!");
            alert.setContentText("Wrong captcha!");
            alert.show();
            changeCaptcha();
        }
        else{
            new MainMenu().start(LoginMenu.stage);
            Menu.setCurrentUser(User.getUserByUsername(username.getText()));
        }
    }
    public void mark() {
        if(visiblePasswordCheckBox.isSelected()){
            password.setVisible(false);
            visiblePassword.setVisible(true);
        }
        if(!visiblePasswordCheckBox.isSelected()){
            password.setVisible(true);
            visiblePassword.setVisible(false);
        }
    }
    public void mark2() {
        if(visibleNewPasswordCheckBox.isSelected()){
            newPassword.setVisible(false);
            visibleNewPassword.setVisible(true);
        }
        if(!visibleNewPasswordCheckBox.isSelected()){
            newPassword.setVisible(true);
            visibleNewPassword.setVisible(false);
        }
    }

    public void setNewPassword() throws IOException {
        String newPass = visibleNewPassword.getText();
        if(Controller.checkPassword(newPass)) {
            Objects.requireNonNull(User.getUserByUsername(username.getText()))
                    .setPassword(visibleNewPassword.getText());
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText("Success!");
            alert.setContentText("Your password is changed successfully!");
            alert.show();
        }
    }

    public void back() throws Exception {
        new StartMenu().start(LoginMenu.stage);
    }
    public void changeCaptcha() {
        AtomicInteger random = new AtomicInteger(Database.getRandomCaptcha());
        LoginMenu.captcha = random;
        Rectangle captcha = new Rectangle(180 , 90); captcha.setFill(new ImagePattern(new Image
                (Objects.requireNonNull(QuestionMenu.class.getResource
                        ("/IMAGES/Captcha/" + random + ".png")).toExternalForm())));
        captcha.setLayoutX(1300); captcha.setLayoutY(400);
        LoginMenu.pane.getChildren().add(captcha);
    }
}
