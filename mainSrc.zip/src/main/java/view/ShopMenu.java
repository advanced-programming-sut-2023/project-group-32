package view;

import controller.Controller;
import controller.GameMenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.*;

import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;
import java.util.regex.Matcher;

public class ShopMenu extends Application {
    static int id = 1;
    private static Stage stage;

    @Override
    public void start(Stage stage) throws Exception {
        ShopMenu.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/shopMenu.fxml");
        Pane pane = FXMLLoader.load(Objects.requireNonNull(url));
        Button close = new Button("Close"); close.setLayoutY(450);close.setLayoutX(350);
        Button showItems = new Button("show items"); showItems.setLayoutY(80);
        showItems.setLayoutX(154);
        Button buySell = new Button("buy/sell"); buySell.setLayoutY(80);
        buySell.setLayoutX(15);
        close.setLayoutX(110);
        close.setOnMouseClicked(mouseEvent -> stage.close());
        buySell.setOnMouseClicked(mouseEvent -> {
            try {
                new ShopMenu2().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        showItems.setOnMouseClicked(mouseEvent -> {
            GameMenuController.showPriceList();
        });
        pane.getChildren().addAll(close , buySell , showItems);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        GameMenu.centerStage(stage);
    }
}
