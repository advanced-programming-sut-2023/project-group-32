package view;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class AvatarMenu extends Application {
    public static Stage stage;
    public static String currentUrl;
    public static File file;
    private ImageView draggedImageView;



    @Override
    public void start(Stage stage) throws Exception {
        AvatarMenu.stage = stage;
        URL url = StartMenu.class.getResource("/FXML/avatarMenu.fxml");
        AnchorPane avatarPane = FXMLLoader.load(url);
        Label label = new Label("Avatar Menu"); label.setLayoutX(860); label.setLayoutY(200);

        Button back = new Button("Back"); back.setLayoutY(900); back.setLayoutX(900);
        Button confirm = new Button("Confirm"); confirm.setLayoutX(900); confirm.setLayoutY(840);
        Button PC = new Button("From your PC"); PC.setLayoutY(780); PC.setLayoutX(900);
        Rectangle chosenRectangle = new Rectangle(820 , 350 , 350 , 350);
        if(!ProfileMenu.fromPC)
            chosenRectangle.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource(Menu.currentUser.getUrlAddress())).toExternalForm())));
        else
            chosenRectangle.setFill(new ImagePattern(new Image(Menu.currentUser.getUrlAddress())));
        Rectangle avatar1 = new Rectangle(200 , 250 , 150 , 150);
        avatar1.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/1.png")).toExternalForm())));
        avatar1.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar1.getFill());
            currentUrl = "/IMAGES/Avatars/1.png";
            file = null;
        });
        Rectangle avatar2 = new Rectangle(200 , 410 , 150 , 150);
        avatar2.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/2.png")).toExternalForm())));
        avatar2.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar2.getFill());
            currentUrl = "/IMAGES/Avatars/2.png";
            file = null;
        });
        Rectangle avatar3 = new Rectangle(200 , 570 , 150 , 150);
        avatar3.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/3.png")).toExternalForm())));
        avatar3.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar3.getFill());
            currentUrl = "/IMAGES/Avatars/3.png";
            file = null;
        });
        Rectangle avatar4 = new Rectangle(200 , 730 , 150 , 150);
        avatar4.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/4.png")).toExternalForm())));
        avatar4.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar4.getFill());
            currentUrl = "/IMAGES/Avatars/4.png";
            file = null;
        });
        Rectangle avatar5 = new Rectangle(500 , 250 , 150 , 150);
        avatar5.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/5.jpg")).toExternalForm())));
        avatar5.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar5.getFill());
            currentUrl = "/IMAGES/Avatars/5.jpg";
            file = null;
        });
        Rectangle avatar6 = new Rectangle(500 , 410 , 150 , 150);
        avatar6.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/6.jpg")).toExternalForm())));
        avatar6.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar6.getFill());
            currentUrl = "/IMAGES/Avatars/6.jpg";
            file = null;
        });
        Rectangle avatar7 = new Rectangle(500 , 570 , 150 , 150);
        avatar7.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/7.png")).toExternalForm())));
        avatar7.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar7.getFill());
            currentUrl = "/IMAGES/Avatars/7.png";
            file = null;
        });
        Rectangle avatar8 = new Rectangle(1300 , 250 , 150 , 150);
        avatar8.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/8.png")).toExternalForm())));
        avatar8.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar8.getFill());
            currentUrl = "/IMAGES/Avatars/8.png";
            file = null;
        });
        Rectangle avatar9 = new Rectangle(1300 , 410 , 150 , 150);
        avatar9.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/9.png")).toExternalForm())));
        avatar9.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar9.getFill());
            currentUrl = "/IMAGES/Avatars/9.png";
            file = null;
        });
        Rectangle avatar10 = new Rectangle(1300 , 570 , 150 , 150);
        avatar10.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/10.png")).toExternalForm())));
        avatar10.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar10.getFill());
            currentUrl = "/IMAGES/Avatars/10.png";
            file = null;
        });
        Rectangle avatar11 = new Rectangle(1600 , 250 , 150 , 150);
        avatar11.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/11.png")).toExternalForm())));
        avatar11.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar11.getFill());
            currentUrl = "/IMAGES/Avatars/11.png";
            file = null;
        });
        Rectangle avatar12 = new Rectangle(1600 , 410 , 150 , 150);
        avatar12.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/12.png")).toExternalForm())));
        avatar12.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar12.getFill());
            currentUrl = "/IMAGES/Avatars/12.png";
            file = null;
        });;
        Rectangle avatar13 = new Rectangle(1600 , 570 , 150 , 150);
        avatar13.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/13.jpg")).toExternalForm())));
        avatar13.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar13.getFill());
            currentUrl = "/IMAGES/Avatars/13.jpg";
            file = null;
        });
        Rectangle avatar14 = new Rectangle(1600 , 730 , 150 , 150);
        avatar14.setFill(new ImagePattern(new Image(Objects.requireNonNull
                (AvatarMenu.class.getResource("/IMAGES/Avatars/tmp.png")).toExternalForm())));
        avatar14.setOnMouseClicked(mouseEvent -> {
            chosenRectangle.setFill(avatar14.getFill());
            currentUrl = "/IMAGES/Avatars/tmp.png";
            file = null;
        });
        avatarPane.getChildren().addAll(back , confirm , PC , chosenRectangle , label);
        avatarPane.getChildren().addAll(avatar1 , avatar2 , avatar3 , avatar4);
        avatarPane.getChildren().addAll(avatar5 , avatar6 , avatar7);
        avatarPane.getChildren().addAll(avatar8 , avatar9 , avatar10);
        avatarPane.getChildren().addAll(avatar11 , avatar12 , avatar13 , avatar14);
        Scene scene = new Scene(avatarPane);
        stage.setScene(scene);
        stage.show();
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new ProfileMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        confirm.setOnMouseClicked(mouseEvent -> {
            try {
                Menu.currentUser.setUrlAddress(currentUrl);
                ProfileMenu.fromPC = file != null;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        PC.setOnMouseClicked(mouseEvent -> {
            FileChooser fileChooser = new FileChooser();
            File selectedFile = fileChooser.showOpenDialog(stage);
            if(selectedFile != null) {
                Image image = new Image(selectedFile.toURI().toString());
                chosenRectangle.setFill(new ImagePattern(image));
                currentUrl = selectedFile.toURI().toString();
                file = selectedFile;
            }
        });
        Rectangle backgroundRect = new Rectangle(820, 340 , 350 , 10);
        backgroundRect.setFill(Color.LIGHTGRAY);

        // Register the drag-over and drag-dropped event handlers for the rectangle
        backgroundRect.setOnDragOver(event -> {
            if (event.getDragboard().hasFiles()) {
                event.acceptTransferModes(TransferMode.ANY);
            }
            event.consume();
        });


        backgroundRect.setOnDragDropped(event -> {
            List<File> files = event.getDragboard().getFiles();
            if (files.size() > 0) {
                File file = files.get(0);
                Image image = new Image(file.toURI().toString());
                ImageView imageView = createImageView(image);
                chosenRectangle.setFill(new ImagePattern(image));
                imageView.relocate(event.getX(), event.getY());
            }
            event.setDropCompleted(true);
            event.consume();
        });

        // Add the rectangle to the pane
        avatarPane.getChildren().add(backgroundRect);
    }
    private ImageView createImageView(Image image) {
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(100);
        imageView.setFitHeight(100);
        imageView.setOnDragDetected(event -> {
            draggedImageView = (ImageView) event.getSource();
            draggedImageView.startDragAndDrop(TransferMode.MOVE);
            event.consume();
        });

        imageView.setOnDragDone(event -> {
            draggedImageView = null;
            event.consume();
        });

        return imageView;
    }
}
