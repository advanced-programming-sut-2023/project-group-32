package view;


import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.regex.Matcher;

public class MainMenu extends Application {

    public static Stage stage;
    public static Pane pane;
    @Override
    public void start(Stage stage) throws Exception {
        /*

        // NEXT LINES ARE CHEAT CODE
        Database.run();
        Menu.currentUser = User.getUserByUsername("username");
        // PREVIOUS LINES ARE CHEAT CODE
        */
        MainMenu.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/MainMenu.fxml");
        pane = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        GameMenu.centerStage(stage);
    }
}
