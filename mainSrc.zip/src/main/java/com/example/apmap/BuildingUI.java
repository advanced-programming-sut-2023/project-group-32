package com.example.apmap;

import javafx.scene.image.Image;
import model.Building;

import java.util.ArrayList;

public class BuildingUI {
    public static ArrayList<BuildingUI> buildingUIS = new ArrayList<>();
    public String buildingName;

    //Reference to building class
    public Building building;
    public Image image;

    public BuildingUI(String buildingName){
        this.buildingName = buildingName;
    }
    public BuildingUI(Building building) {
        this.building = building;
        this.buildingName = building.getName();
    }
}
