package com.example.apmap;

import model.Troop;

import java.util.ArrayList;

public class TroopUI {
    public static ArrayList<TroopUI> muslimTroops = new ArrayList<>();
    public static ArrayList<TroopUI> christianTroops = new ArrayList<>();

    public String troopName;
    public Troop troop;

    public  TroopUI(Troop troop){
        this.troop = troop;
        this.troopName = troop.getTroopName();
    }
}
