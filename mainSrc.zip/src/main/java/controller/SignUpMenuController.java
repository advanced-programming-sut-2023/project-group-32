package controller;

import model.Database;
import model.User;
import view.Menu;
import view.messages.SignUpMenuMessages;

import java.io.IOException;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static view.messages.SignUpMenuMessages.*;

public class SignUpMenuController {


    public static SignUpMenuMessages login(String content) throws InterruptedException, IOException {
        String username = Controller.getPart(content , "-u");
        String password = Controller.getPart(content , "-p");
        if(username == null || password == null)
            return NULL_FIELDS;
        if(User.getUserByUsername(username) == null)
            return USERNAME_DOES_NOT_EXIST;
        User user = User.getUserByUsername(username);
        String realPassword = null;
        if (user != null) {
            realPassword = user.getPassword();
        }
        password = Controller.hashMaker(password);
        if(Menu.checkPassword(realPassword , "login", password))
            return null;
        if (Menu.captcha())
            return null;
        Matcher matcher = Pattern.compile("--stay-logged-in").matcher(content);
        if(matcher.find()){
            if (user != null) {
                Controller.stayLoggedIn(user);
            }
        }
        Menu.currentUser = User.getUserByUsername(username);
        return SUCCESS;
    }
    public static String randomPassword(){
            UUID randomUUID = UUID.randomUUID();
            return randomUUID.toString().replaceAll("-", "");
    }
    public static String modifyPassword(String password){
        password = password.replaceAll("\\*" , "\\\\*");
        password = password.replaceAll("\\(" , "\\\\(");
        password = password.replaceAll("\\)" , "\\\\)");
        password = password.replaceAll("\\[" , "\\\\[");
        return password;
    }
}
