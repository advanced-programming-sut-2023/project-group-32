package model;

public class Resource {
    public String type = "";
    public int amount = 0;
}
