package model;

public class Food {
    public enum FoodType { bread , meat , cheese , apple }
    public FoodType foodType;
    public int number;
}