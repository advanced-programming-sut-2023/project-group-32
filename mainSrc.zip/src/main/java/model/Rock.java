package model;

public class Rock {
    public String direction;
    public Government owner;
    int x , y;
    public Rock(int x , int y , String direction , Government owner){
        this.owner = owner;
        this.x = x;
        this.y = y;
        this.direction = direction;
    }
}
