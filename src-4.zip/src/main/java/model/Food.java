package model;

public class Food {
    public enum foodType { food1 , food2 , food3 , food4 }
}
