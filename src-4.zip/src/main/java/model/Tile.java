package model;

import java.util.ArrayList;

public class Tile {
    public int x , y;
    public ArrayList<Troop> troops;
    public Building building;
    public Resource resource;
    public Tree tree;
    //Dust, DustRock, Rock, Iron, Stone, Meadow, MeadowDense, Grass
    public String tileType;

    Tile(String tileType){
        troops = new ArrayList<>();
        this.tileType = tileType;
        resource = null;
        tree = null;
        building = null;
    }
}
