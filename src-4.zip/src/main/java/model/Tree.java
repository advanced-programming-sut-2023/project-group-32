package model;

public class Tree {
}
