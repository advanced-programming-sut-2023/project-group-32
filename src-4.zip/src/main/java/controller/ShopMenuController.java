package controller;

public class ShopMenuController {
    public static void showPriceList(){

    }
    public static void buy(String content){

    }
    public static void sell(String content){

    }
}
