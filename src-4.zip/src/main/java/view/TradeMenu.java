package view;

public class TradeMenu {
    public static void run(){
        String command;
        while (true){
            command = Menu.getScanner().nextLine();
            if(command.matches("^\\s*show\\s+current\\s+menu\\s*$"))
                System.out.println("Trade Menu");
            else if(command.matches("^\\s*back\\s*$")){
                System.out.println("Exited Trade Menu!");
                return;
            }
        }
    }
}
