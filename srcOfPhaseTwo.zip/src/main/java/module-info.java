module com.example.apmap {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.apmap to javafx.fxml;
    opens view to javafx.fxml;
    exports com.example.apmap;
    exports model;
    exports view;
    opens model to javafx.fxml;
}