package model;

import java.util.ArrayList;

public class ProductionBuilding extends Building{
    ArrayList<InventorySlot> outputs;
    ArrayList<InventorySlot> inputs;

    public ProductionBuilding(String pictureName , int hp, ArrayList<InventorySlot> costs, String name, BuildingType buildingType, int requiredWorkers , int popularityRate, ArrayList<InventorySlot> outputs, ArrayList<InventorySlot> inputs) {
        super(pictureName , hp, costs, name, buildingType, requiredWorkers,  popularityRate);
        this.outputs = outputs;
        this.inputs = inputs;
    }
    public void update(Inventory inventory){
        if(inventory.hasInventory(inputs)){
            inventory.removeInventory(inputs);
            inventory.addInventory(outputs);
        }
    }
}
