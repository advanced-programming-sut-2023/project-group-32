package model;

import java.util.ArrayList;

public class BuildingUI {
    public static ArrayList<BuildingUI> buildingUIS = new ArrayList<>();
    public String buildingName;

    //Reference to building class
    //public Building building;

    public BuildingUI(String buildingName){
        this.buildingName = buildingName;
    }
}
