package view;

import controller.Controller;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.net.URL;
import java.util.Objects;

public class TradeMenu2 extends Application {
    public static Stage stage;
    @Override
    public void start(Stage stage) throws Exception {
        TradeMenu2.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/tradeMenu2.fxml");
        Pane pane = FXMLLoader.load(Objects.requireNonNull(url));
        Button back = new Button("Back");
        Label label = new Label("Trade history!");
        label.setStyle("-fx-font-weight: BOLD; -fx-text-fill: white; -fx-font-size: 30; -fx-background-color: red; -fx-background-radius: 35;");
        label.setLayoutX(520); label.setLayoutY(130);
        back.setLayoutX(550); back.setLayoutY(700);
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new TradeMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        int counter = 1;
        for (String trade : GameMenu.trades) {
            if(Objects.equals(Controller.getPart(trade, "receiver:"), GameMenu.currentPLayer.getUsername()) || Objects.equals(Controller.getPart(trade, "sender:"), GameMenu.currentPLayer.getUsername())) {
                Label lab = new Label(trade); lab.setLayoutX(40);
                lab.setLayoutY(50 + (counter * 15));
                pane.getChildren().add(lab);
                counter++;
            }
        }
        pane.getChildren().addAll(label , back);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        GameMenu.centerStage(stage);
        pane.requestFocus();
        pane.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if(keyEvent.getCode().getName().equals("B")) {
                    try {
                        new TradeMenu().start(stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    }
}
