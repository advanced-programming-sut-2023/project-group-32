package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import model.Database;

import java.net.URL;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class LoginMenu extends Application {
    public static Stage stage;
    public static Pane pane;
    public static AtomicInteger captcha;
    @Override
    public void start(Stage stage) throws Exception {
        AtomicInteger random = new AtomicInteger(Database.getRandomCaptcha());
        captcha = random;
        Rectangle captcha = new Rectangle(180 , 90); captcha.setFill(new ImagePattern(new Image
                (Objects.requireNonNull(QuestionMenu.class.getResource
                        ("/IMAGES/Captcha/" + random + ".png")).toExternalForm())));
        captcha.setLayoutX(1300); captcha.setLayoutY(400);
        LoginMenu.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/loginMenu.fxml");
        pane = FXMLLoader.load(url); pane.getChildren().addAll(captcha);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }

}
