package view;

import controller.Controller;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import model.Database;
import model.User;

import static controller.SignUpMenuController.randomPassword;

public class SignUpMenuGraphicController {
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private TextField email;
    @FXML
    private TextField nickname;
    @FXML
    private TextField slogan;

    @FXML
    private TextField visiblePassword;
    @FXML
    private CheckBox visiblePasswordCheckBox;
    @FXML
    private CheckBox sloganCheckBox;
    @FXML
    private CheckBox randomPasswordCheckBox;
    @FXML
    private CheckBox randomSloganCheckBox;
    @FXML
    private Text usernameError;
    @FXML
    private Text passwordError;
    @FXML
    private Text emailError;
    @FXML
    private Text nicknameError;
    @FXML
    private Text sloganError;
    @FXML
    private void initialize() {
        password.textProperty().addListener((observable, oldText, newText)->{
            visiblePassword.setText(newText);
        });
        visiblePassword.textProperty().addListener((observable, oldText, newText)->{
            password.setText(newText);
        });
        usernameError.setFont(new Font(16));
        passwordError.setFont(new Font(16));
        emailError.setFont(new Font(16));
        nicknameError.setFont(new Font(16));
        sloganError.setFont(new Font(16));
        username.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                usernameError.setText("You must have a username!");
            else if(!newText.matches("[\\w \t]+")) {
                usernameError.setText("Incorrect format for username!");
            }
            else if(User.getUserByUsername(newText) != null)
                usernameError.setText("Username already exists!");
            else
                usernameError.setText("");
        });
        password.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                passwordError.setText("You must have a password!");
            else if(!Controller.checkPassword(newText) && !randomPasswordCheckBox.isSelected())
                passwordError.setText("Your password is weak!");
            else
                passwordError.setText("");
        });
        email.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                emailError.setText("You must have an email!");
            else if(!newText.matches("\\S+@\\S+\\.\\S+"))
                emailError.setText("Invalid format for email!");
            else if(User.getUserByEmail(newText) != null)
                emailError.setText("Email already exists~");
            else
                emailError.setText("");
        });
        nickname.textProperty().addListener((observable, oldText, newText)->{
            if(newText.equals(""))
                nicknameError.setText("You must have a nick name!");
            else
                nicknameError.setText("");
        });
    }
    public void confirm() throws Exception {
        boolean ERROR = false;
        if(username.getText().equals("")) {
            ERROR = true;
        }
        else if(!username.getText().matches("[\\w \t]+")) {
            ERROR = true;
        }
        else if(User.getUserByUsername(username.getText()) != null) {
            ERROR = true;
        }
        if(password.getText().equals("")) {
            ERROR = true;
        }
        else if(!Controller.checkPassword(password.getText()) && !randomPasswordCheckBox.isSelected()) {
            ERROR = true;
        }
        if(nickname.getText().isEmpty()) {
            nicknameError.setText("You must have a nick name!");
            ERROR = true;
        }
        else
            nicknameError.setText("");
        if(email.getText().isEmpty()) {
            emailError.setText("You must have an email!");
            ERROR = true;
        }
        else if(!email.getText().matches("\\S+@\\S+\\.\\S+")) {
            emailError.setText("Incorrect format for email!");
            ERROR = true;
        }
        else
            emailError.setText("");
        if(sloganCheckBox.isSelected() && !randomSloganCheckBox.isSelected() && slogan.getText().isEmpty()) {
            sloganError.setText("You didn't type your slogan!");
            ERROR = true;
        }
        else {
            sloganError.setText("");
        }

        if(!ERROR) {
            QuestionMenu.setUser(username.getText() , password.getText() , nickname.getText() , email.getText() , slogan.getText());
            new QuestionMenu().start(SignUpMenu.getStage());
        }
    }

    public void mark() {
        if(visiblePasswordCheckBox.isSelected()){
            password.setVisible(false);
            visiblePassword.setVisible(true);
        }
        if(!visiblePasswordCheckBox.isSelected()){
            password.setVisible(true);
            visiblePassword.setVisible(false);
        }
    }

    public void mark2() {
        if(randomPasswordCheckBox.isSelected()) {
            String randomPassword = randomPassword().substring(0 , 8);
            password.setText(randomPassword);
        }
        else
            password.setText("");
    }
    public void mark3() {
        if(sloganCheckBox.isSelected()) {
            slogan.setVisible(true);
            randomSloganCheckBox.setVisible(true);
        }
        else {
            slogan.setText("");
            randomSloganCheckBox.setSelected(false);
            slogan.setVisible(false);
            randomSloganCheckBox.setVisible(false);
        }
    }
    public void mark4() {
        if(randomSloganCheckBox.isSelected()){
            int random = (int) Math.floor(Math.random() * 15);
            String sloganText = Database.slogans[random];
            slogan.setText(sloganText);
        }
        else
            slogan.setText("");
    }

    public void back() throws Exception {
        new StartMenu().start(SignUpMenu.getStage());
    }
}
