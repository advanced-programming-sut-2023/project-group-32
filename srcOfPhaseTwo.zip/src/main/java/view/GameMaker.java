package view;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.User;

import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;

public class GameMaker extends Application {
    public static Stage stage;
    public Label label = new Label();
    public ArrayList<User> players = new ArrayList<>();
    public TextField textField = new TextField();
    public Label top = new Label();

    @Override
    public void start(Stage stage) throws Exception {
        GameMaker.stage = stage;
        Pane pane;
        URL url = MainMenu.class.getResource("/FXML/gameMaker.fxml");
        pane = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(pane , 1920 , 1080);
        stage.setScene(scene);
        stage.show();
    }
    public void back() throws Exception {
        new MainMenu().start(stage);
    }

    public void start() throws Exception {
        if(players.isEmpty())
            players.add(Menu.currentUser);
        GameMaker2 gameMaker2 = new GameMaker2();
        gameMaker2.setPlayers(players);
        gameMaker2.start(stage);
    }

    public void add() {
        User user = User.getUserByUsername(textField.getText());
        if(players.isEmpty())
            players.add(Menu.currentUser);
        int count = (int) label.getText().chars()
                .filter(ch -> ch == '\n')
                .count();
        if(count == 8) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("More than 8 players!");
            alert.show();
        }
        else if(Objects.equals(user, Menu.currentUser)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("You don't need to write your name!");
            alert.show();
        }
        else if(players.contains(user)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("You already added this user!");
            alert.show();
        }
        else if(user != null) {
            StringBuilder text = new StringBuilder();
            players.add(user);
            label.setText("");
            for (User player : players) {
                text.append(player.getUsername()).append("\n");
            }
            label.setText(text.toString());
            textField.setText("");
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("No user found!");
            alert.show();
        }
    }
}
