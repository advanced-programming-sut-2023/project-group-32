package view;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.User;

import java.net.URL;
import java.util.Objects;

public class TradeMenu4 extends Application {
    private static Stage stage;
    private User selectedUser;
    public void setSelectedUser(User user) {
        this.selectedUser = user;
    }
    @Override
    public void start(Stage stage) throws Exception {
        TradeMenu4.stage = stage;
        Label withUser = new Label(selectedUser.getUsername());
        URL url = MainMenu.class.getResource("/FXML/tradeMenu4.fxml");
        Pane pane = FXMLLoader.load(Objects.requireNonNull(url));
        withUser.setStyle("-fx-background-radius: 45; -fx-background-color: red; -fx-text-fill: white; -fx-font-size: 20;");
        Button back = new Button("Back");
        back.setLayoutX(550); back.setLayoutY(600);
        withUser.setLayoutX(550); withUser.setLayoutY(200);
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new TradeMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        pane.getChildren().addAll(back , withUser);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        GameMenu.centerStage(stage);
    }
}
