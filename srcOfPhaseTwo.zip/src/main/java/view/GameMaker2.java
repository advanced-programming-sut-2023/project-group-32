package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Objects;

public class GameMaker2 extends Application {
    private static Stage stage;
    private int counter;
    private static ArrayList<User> players = new ArrayList<User>();
    public Label name;
    public TextField x;
    public TextField y;

    public void setPlayers(ArrayList<User> players) {
        GameMaker2.players = players;
        this.counter = 0;
    }
    @Override
    public void start(Stage stage) throws Exception {
        GameMaker2.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/gameMaker2.fxml");
        Pane pane = FXMLLoader.load(Objects.requireNonNull(url));
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }
    public void initialize() {
        name.setText(players.get(counter).getUsername());
    }

    public void submit() throws IOException {
        if(checkNumbers()) {
            if (this.counter == players.size() - 1) {
                GameMenu gameMenu = new GameMenu();
                gameMenu.setPlayers(players);
                gameMenu.start(stage);
            } else {
                players.get(counter).getGovernment().getHeadquarter().setX(Integer.parseInt(x.getText()));
                players.get(counter).getGovernment().getHeadquarter().setY(Integer.parseInt(y.getText()));
                players.get(counter).getGovernment().getHeadquarter().setOwner(players.get(counter).getGovernment());
                x.setText("");
                y.setText("");
                this.counter++;
                name.setText(players.get(counter).getUsername());
            }
        }
    }
    public void back() throws Exception {
        new MainMenu().start(stage);
    }
    public boolean checkNumbers() {
        if(x.getText().matches("\\d+") && y.getText().matches("\\d+")) {
            for (User player : players) {
                if(player.getGovernment().getHeadquarter().getX() == Integer.parseInt(x.getText()) &&
                player.getGovernment().getHeadquarter().getY() == Integer.parseInt(y.getText())) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("This tile has already been chosen by another player!");
                    alert.show();
                    return false;
                }
                else if(Integer.parseInt(x.getText()) < 0 || Integer.parseInt(x.getText()) >= 200
                || Integer.parseInt(y.getText()) < 0 || Integer.parseInt(y.getText()) >= 200) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Wrong coordinates!");
                    alert.show();
                    return false;
                }
            }
            return true;
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Invalid input!");
            alert.show();
            return false;
        }
    }
}
