package view;

import controller.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToolBar;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import model.BuildingUI;

public class HelloController extends Controller {

    private static final int GRID_SIZE = 200;
    private static final int VISIBLE_SIZE = 10;
    private static final int CELL_SIZE = 60;

    private GridPane gridPane;
    private Circle buildingImage;
    private double startX, startY;
    private Boolean inBuilding = false;

    @FXML
    private StackPane stackPane;
    @FXML
    private ToolBar mainToolBar;
    @FXML
    private ToolBar buildingToolBar;
    @FXML
    private Button backButton;

    //Building ToolBar
    @FXML
    private Button nextBuilding;
    @FXML
    private Button prevBuilding;
    @FXML
    private Button firstBuilding;
    @FXML
    private Button secondBuilding;
    @FXML
    private Button thirdBuilding;
    public int middleBuildingIndex = 1;

    //Cell Details
    @FXML
    private AnchorPane cellDetails;
    @FXML
    private Text cellBuilding;
    @FXML
    private Text cellCoordinates;
    @FXML
    private Text cellTroops;

    public void Awake() {
        gridPane = createGridPane();
        stackPane.getChildren().add(0, gridPane);

        buildingToolBar.setVisible(false);

        //Initializing Building UIs. Should be done in Database class
        BuildingUI.buildingUIS.add(new BuildingUI("Building One"));
        BuildingUI.buildingUIS.add(new BuildingUI("Building Two"));
        BuildingUI.buildingUIS.add(new BuildingUI("Building Three"));
        BuildingUI.buildingUIS.add(new BuildingUI("Building Four"));
        BuildingUI.buildingUIS.add(new BuildingUI("Building Five"));
        BuildingUI.buildingUIS.add(new BuildingUI("Building Six"));

        nextBuilding.setOnMouseClicked(event -> NextBuilding());
        prevBuilding.setOnMouseClicked(event -> PreviousBuilding());

        firstBuilding.setText(BuildingUI.buildingUIS.get(0).buildingName);
        secondBuilding.setText(BuildingUI.buildingUIS.get(1).buildingName);
        thirdBuilding.setText(BuildingUI.buildingUIS.get(2).buildingName);

        firstBuilding.setOnMouseClicked(event -> Build());
        secondBuilding.setOnMouseClicked(event -> Build());
        thirdBuilding.setOnMouseClicked(event -> Build());

        backButton.setOnMouseClicked(event -> BackButtonClicked());
        backButton.setVisible(false);

        cellDetails.setVisible(false);
        prevBuilding.setVisible(false);
    }
    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(1);
        gridPane.setVgap(1);

        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                Rectangle rect = new Rectangle(CELL_SIZE, CELL_SIZE, Color.WHITE);
                rect.setStroke(Color.LIGHTGRAY);

                Text text = new Text(col + "," + row);

                text.setFill(Color.BLACK);
                text.setVisible(false);

                StackPane stackPane = new StackPane(rect, text);
                stackPane.setAlignment(Pos.CENTER);

                final int currentCol = col;
                final int currentRow = row;

                stackPane.setOnMouseEntered(event -> handleMouseEnter(currentCol, currentRow));
                stackPane.setOnMouseExited(event -> handleMouseExit(currentCol, currentRow));
                stackPane.setOnMouseClicked(event -> handleMouseClicked(currentCol, currentRow));

                gridPane.add(stackPane, col, row);
            }
        }
        Circle circle = new Circle();
        circle.setRadius(10);
        circle.setVisible(false);

        gridPane.getChildren().add(circle);

        gridPane.setOnMouseMoved(event -> {
            circle.setTranslateX(event.getX() - circle.getRadius() / 2);
            circle.setTranslateY(event.getY() - circle.getRadius() * 2);
        });
        gridPane.setOnScroll(event -> {
            double deltaY = event.getDeltaY();
            double zoomFactor = 1.05;

            if (deltaY < 0) {
                zoomFactor = 1 / zoomFactor;
            }

            gridPane.setScaleX(gridPane.getScaleX() * zoomFactor);
            gridPane.setScaleY(gridPane.getScaleY() * zoomFactor);

            event.consume();
        });
        this.buildingImage = circle;
        return gridPane;
    }
    public void BuildButtonClicked(){
        //buildingImage.setVisible(true);
        //inBuilding = true;

        mainToolBar.setVisible(false);
        buildingToolBar.setVisible(true);

        backButton.setVisible(true);
    }
    public void NextBuilding(){
        int buildingAmounts = BuildingUI.buildingUIS.size();

        middleBuildingIndex++;
        prevBuilding.setVisible(true);

        firstBuilding.setText(BuildingUI.buildingUIS.get(middleBuildingIndex - 1).buildingName);
        secondBuilding.setText(BuildingUI.buildingUIS.get(middleBuildingIndex).buildingName);
        thirdBuilding.setText(BuildingUI.buildingUIS.get(middleBuildingIndex + 1).buildingName);

        if(middleBuildingIndex + 1 == buildingAmounts - 1)
            nextBuilding.setVisible(false);
    }
    public void PreviousBuilding(){
        middleBuildingIndex--;
        nextBuilding.setVisible(true);

        firstBuilding.setText(BuildingUI.buildingUIS.get(middleBuildingIndex - 1).buildingName);
        secondBuilding.setText(BuildingUI.buildingUIS.get(middleBuildingIndex).buildingName);
        thirdBuilding.setText(BuildingUI.buildingUIS.get(middleBuildingIndex + 1).buildingName);

        if(middleBuildingIndex - 1 == 0)
            prevBuilding.setVisible(false);
    }
    public void Build(){
        inBuilding = true;
        buildingImage.setVisible(true);
    }
    public void BackButtonClicked(){
        inBuilding = false;
        buildingImage.setVisible(false);

        mainToolBar.setVisible(true);
        buildingToolBar.setVisible(false);
        backButton.setVisible(false);
    }
    private void handleMouseClicked(int col, int row){
        if(!inBuilding) {
            cellDetails.setVisible(true);
            ShowDetails(col, row);
            return;
        }

        Circle circle = new Circle();
        circle.setRadius(10);
        circle.setVisible(true);

        circle.setFill(Color.RED);

        gridPane.getChildren().add(circle);

        Rectangle rect = getRectangleByCoordinates(col, row);
        if(rect == null) return;

        circle.setTranslateX(buildingImage.getTranslateX());
        circle.setTranslateY(buildingImage.getTranslateY());

        buildingImage.setVisible(false);
        inBuilding = false;
    }
    private void handleMouseEnter(int col, int row) {
        /*Rectangle rect = getRectangleByCoordinates(col, row);
        if (rect != null) {
            Text text = (Text) ((StackPane) rect.getParent()).getChildren().get(1);
            text.setVisible(true);
        }*/
    }
    private void handleMouseExit(int col, int row) {
        /*Rectangle rect = getRectangleByCoordinates(col, row);
        if (rect != null) {
            Text text = (Text) ((StackPane) rect.getParent()).getChildren().get(1);
            text.setVisible(false);
        }*/
    }
    public void handleMousePressed(MouseEvent event) {
        startX = event.getSceneX();
        startY = event.getSceneY();
    }
    public void handleMouseDragged(MouseEvent event) {
        if (event.getButton() == MouseButton.PRIMARY) {
            double deltaX = event.getSceneX() - startX;
            double deltaY = event.getSceneY() - startY;

            double translateX = deltaX / CELL_SIZE;
            double translateY = deltaY / CELL_SIZE;

            float mouseSensitivity = 5f;
            gridPane.setTranslateX(gridPane.getTranslateX() + translateX * mouseSensitivity);
            gridPane.setTranslateY(gridPane.getTranslateY() + translateY * mouseSensitivity);

            startX = event.getSceneX();
            startY = event.getSceneY();
        }
    }
    private Rectangle getRectangleByCoordinates(int x, int y) {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof StackPane) {
                StackPane stackPane = (StackPane) node;
                int col = GridPane.getColumnIndex(stackPane);
                int row = GridPane.getRowIndex(stackPane);
                if (col == x && row == y) {
                    return (Rectangle) stackPane.getChildren().get(0);
                }
            }
        }
        return null; // Return null if the rectangle is not found
    }
    //Cell Details
    @FXML
    void closeCellDetails(ActionEvent event) {
        cellDetails.setVisible(false);
    }
    void ShowDetails(int col, int row){
        cellCoordinates.setText("Coordinates: " + col + "," + row);
        cellBuilding.setText("Building: None");
        cellTroops.setText("Troops: 0");
    }
}