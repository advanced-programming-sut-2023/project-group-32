package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import java.net.URL;


public class SignUpMenu extends Application {
    public static Pane pane;
    public static Stage stage;
    @Override
    public void start(Stage stage) throws Exception {
        URL url = MainMenu.class.getResource("/FXML/signUpMenu.fxml");
        pane = FXMLLoader.load(url);
        SignUpMenu.stage = stage;
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }
    public static Pane getPane() {
        return pane;
    }
    public static Stage getStage(){
        return stage;
    }
}
