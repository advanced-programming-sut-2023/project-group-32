package view;

import com.example.apmap.HelloController;
import controller.Controller;
import controller.GameMenuController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import model.Item;
import model.Storage;

import java.net.URL;
import java.util.Objects;

import static controller.GameMenuController.currentGovernment;
import static controller.GameMenuController.patrolUnit;

public class ShopMenu2 extends Application {
    public static Stage stage;
    @Override
    public void start(Stage stage) throws Exception {
        TradeMenu2.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/shopMenu2.fxml");
        Pane pane = FXMLLoader.load(Objects.requireNonNull(url));
        Button back = new Button("Back");
        Label label = new Label("Shop");
        label.setStyle("-fx-font-weight: BOLD; -fx-text-fill: white; -fx-font-size: 30; -fx-background-color: red; -fx-background-radius: 35;");
        label.setLayoutX(520); label.setLayoutY(130);
        back.setLayoutX(550); back.setLayoutY(700);
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new ShopMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        TextField itemName = new TextField("item name");
        itemName.setLayoutX(300); itemName.setLayoutY(250);
        itemName.setMinWidth(200);
        Text error = new Text();
        error.setX(700); error.setY(265);
        Button showDetail = new Button("confirm");
        showDetail.setLayoutX(550); showDetail.setLayoutY(250);
        Text itemNumber = new Text("");
        itemNumber.setY(250+37.5); itemNumber.setX(400);
        Text price = new Text("");
        price.setY(250+2*37.5); price.setX(400);
        Text gold = new Text("");
        gold.setY(250+3*37.5); gold.setX(400);
        TextField number = new TextField("number");
        number.setLayoutY(400); number.setLayoutX(300); number.setVisible(false);
        Button buyButton = new Button("Buy");
        Button sellButton = new Button("Sell");
        buyButton.setLayoutY(450); buyButton.setLayoutX(600); buyButton.setVisible(false);
        sellButton.setLayoutY(500); sellButton.setLayoutX(600); sellButton.setVisible(false);
        // ino ye lahze static kardam bebinam ok mishe ya na
        Storage Stockpile = (Storage) HelloController.government.getBuildingByName("Stockpile");


        showDetail.setOnMouseClicked(mouseEvent -> {
            Item item = Item.getItemByName(itemName.getText());
            if(Stockpile == null) {
                error.setText("You should build Stockpile first!");
                itemNumber.setVisible(false);
                price.setVisible(false);
                gold.setVisible(false);
                number.setVisible(false);
                buyButton.setVisible(false);
                sellButton.setVisible(false);
            }
            else if(item == null) {
                error.setText("Invalid Item Name");
                itemNumber.setVisible(false);
                price.setVisible(false);
                gold.setVisible(false);
                number.setVisible(false);
                buyButton.setVisible(false);
                sellButton.setVisible(false);
            }
            else{
                price.setText(String.valueOf(item.getPrice()));
                itemNumber.setText(String.valueOf(Stockpile.getInventory().getAmount(item.getName())));
                gold.setText(String.valueOf(Stockpile.getInventory().getAmount("Gold")));
                error.setText("");
                itemNumber.setVisible(true);
                price.setVisible(true);
                gold.setVisible(true);
                number.setVisible(true);
                buyButton.setVisible(true);
                sellButton.setVisible(true);
            }
        });

        buyButton.setOnMouseClicked(mouseEvent -> {
            int currentGold = Stockpile.getInventory().getAmount("Gold");
            Item item = Item.getItemByName(itemName.getText());
            int totalPrice = Integer.parseInt(number.getText()) * item.getPrice();
            if(currentGold < totalPrice){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("error");
                alert.setHeaderText("not enough gold!");
                alert.showAndWait();
                return;
            }
            Stockpile.getInventory().addAmount(item , Integer.parseInt(number.getText()));
            Stockpile.getInventory().addAmount("Gold", -1 * totalPrice);
            itemNumber.setText(String.valueOf(Stockpile.getInventory().getAmount(item.getName())));
            gold.setText(String.valueOf(Stockpile.getInventory().getAmount("Gold")));
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setHeaderText("item bought successfully");
            alert.showAndWait();
        });

        sellButton.setOnMouseClicked(mouseEvent -> {
            Item item = Item.getItemByName(itemName.getText());
            int currentItemAmount = Stockpile.getInventory().getAmount(itemName.getText());
            int amount = Integer.parseInt(number.getText());
            if(currentItemAmount < amount){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("error");
                alert.setHeaderText("not enough item!");
                alert.showAndWait();
                return;
            }
            Stockpile.getInventory().addAmount("Gold", item.getPrice() * amount * 7 / 10);
            Stockpile.getInventory().addAmount(item, -amount);
            itemNumber.setText(String.valueOf(Stockpile.getInventory().getAmount(item.getName())));
            gold.setText(String.valueOf(Stockpile.getInventory().getAmount("Gold")));

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Successful");
            alert.setHeaderText("item bought successfully");
            alert.showAndWait();
        });


        pane.getChildren().addAll(label ,itemName , showDetail , error , itemNumber , price , number , sellButton , buyButton , gold ,  back);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        GameMenu.centerStage(stage);
    }
}
