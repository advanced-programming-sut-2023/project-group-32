package view;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.net.URL;
import java.util.Objects;

public class TradeMenu3 extends Application {
    private static Stage stage;
    @Override
    public void start(Stage stage) throws Exception {
        TradeMenu3.stage = stage;
        URL url = MainMenu.class.getResource("/FXML/tradeMenu3.fxml");
        Label label = new Label("Request new Trade!");
        label.setLayoutY(110); label.setLayoutX(320);
        label.setStyle("-fx-font-weight: BOLD; -fx-text-fill: red; -fx-font-size: 30");
        Pane pane = FXMLLoader.load(Objects.requireNonNull(url));
        pane.getChildren().addAll(label);
        Button back = new Button("Back");
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new TradeMenu().start(TradeMenu3.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        back.setLayoutY(650); back.setLayoutX(360);
        pane.getChildren().add(back);
        int counter = 1;
        for (User user : GameMenu.players) {
            if(user != GameMenu.currentPLayer) {
                Label player = new Label(user.getUsername());
                player.setLayoutX(270);
                Button choose = new Button("Choose");
                choose.setLayoutY(163 + (counter * 60));
                choose.setLayoutX(520);
                player.setStyle("-fx-font-weight: BOLD; -fx-text-fill: red; -fx-font-size: 30");
                player.setLayoutY(150 + (counter * 60));
                pane.getChildren().addAll(player, choose);
                counter++;
                choose.setOnMouseClicked(mouseEvent -> {
                    TradeMenu4 tradeMenu4 = new TradeMenu4();
                    try {
                        tradeMenu4.setSelectedUser(User.getUserByUsername(player.getText()));
                        tradeMenu4.start(stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                });
            }
        }
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        GameMenu.centerStage(stage);
        pane.requestFocus();
        pane.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if(keyEvent.getCode().getName().equals("B")) {
                    try {
                        new TradeMenu().start(stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    }
}
