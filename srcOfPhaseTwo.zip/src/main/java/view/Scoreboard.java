package view;

import controller.Controller;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Database;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;

public class Scoreboard extends Application {
    private int pageNumber;
    private static String selectedUrl;

    private static Stage stage;

    @Override
    public void start(Stage stage) throws Exception {
        Scoreboard.stage = stage;

        URL url = StartMenu.class.getResource("/FXML/scoreboard.fxml");
        AnchorPane pane = FXMLLoader.load(url);
        User.ScoreBoard();
        for(int i = (pageNumber - 1) * 10 ; i < pageNumber * 10 && i < User.getUsers().size() ; i++) {
            Label username = new Label((i+1) + ")username: " + User.getUsers().get(i).getUsername());
            Label highScore = new Label("high score: " + User.getUsers().get(i).getHighScore());
            Rectangle avatar = new Rectangle(1200 , 80 + (85 * (i % 10)) , 80 , 80);
            if(!User.getUsers().get(i).getUrlAddress().contains("file:"))
                avatar.setFill(new ImagePattern(new Image(Objects.requireNonNull(QuestionMenu.class.getResource
                        (User.getUsers().get(i).getUrlAddress())).toExternalForm())));
            else
                avatar.setFill(new ImagePattern(new Image(User.getUsers().get(i).getUrlAddress())));
            highScore.setLayoutX(800);
            highScore.setLayoutY(80 + (85 * (i % 10)));
            username.setLayoutY(80 + (85 * (i % 10)));
            username.setLayoutX(300);
            username.setMinWidth(350);
            highScore.setMinWidth(180);
            Font font = new Font("Arial", 50);
            username.setFont(font);
            pane.getChildren().addAll(username , highScore , avatar);
        }
        Button back = new Button("Back"); back.setLayoutX(1500); back.setLayoutY(600);
        Button down = new Button("Down"); down.setLayoutX(1500); down.setLayoutY(520);
        down.setOnMouseClicked(mouseEvent -> {
            if(!(pageNumber * 10 > User.getUsers().size())) {
                Scoreboard scoreboard = new Scoreboard();
                scoreboard.setPage(pageNumber + 1);
                try {
                    scoreboard.start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        Button up = new Button("Up");  up.setLayoutX(1500); up.setLayoutY(490);
        up.setOnMouseClicked(mouseEvent -> {
            if(pageNumber > 1) {
                Scoreboard scoreboard = new Scoreboard();
                scoreboard.setPage(pageNumber - 1);
                try {
                    scoreboard.start(stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
        pane.getChildren().addAll(back , down , up);
        back.setOnMouseClicked(mouseEvent -> {
            try {
                new MainMenu().start(stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        pane.setOnMouseClicked(mouseEvent -> {
            if(mouseEvent.getX() >= 1200 && mouseEvent.getX() <= 1280) {
                for(int i = 0 ; i < 10 ; i++) {
                    if(mouseEvent.getY() > 80 + (85 * i) && mouseEvent.getY() < 160 + (85 * i)) {
                        confirmation(i);
                    }
                }
            }
        });
    }
    public void setPage(int page) {
        this.pageNumber = page;
    }
    public void confirmation(int i){
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Change Avatar");
        dialog.setHeaderText("Change Avatar");

        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialog.getDialogPane().getButtonTypes().addAll(okButton, cancelButton);

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        Label label = new Label("Do you want to change your avatar\n to the avatar that you selected?");
        label.setFont(new Font("Arial" , 20));
        grid.addRow(0 , label);
        dialog.getDialogPane().setContent(grid);

        dialog.getDialogPane().setPrefWidth(500);
        dialog.getDialogPane().setPrefHeight(250);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == okButton) {
                selectedUrl = User.getUsers().get((10 * (pageNumber - 1)) + i).getUrlAddress();
                try {
                    Menu.currentUser.setUrlAddress(selectedUrl);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                return ButtonType.OK;
            }
            else {
                return ButtonType.CANCEL;
            }
        });
        dialog.show();
    }
}
