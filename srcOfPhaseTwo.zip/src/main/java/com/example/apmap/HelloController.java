package com.example.apmap;

import controller.GameMenuController;
import controller.MapMenuController;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import model.*;
import view.MapMenu;
import view.ShopMenu;
import view.TradeMenu;

import java.io.IOException;
import java.io.PushbackReader;
import java.util.ArrayList;
import java.util.Random;

public class HelloController extends Controller{
    public static HelloController instance;
    private static final int GRID_SIZE = 200;
    private static final int VISIBLE_SIZE = 10;
    private static final int CELL_SIZE = 60;

    static private GridPane gridPane;
    static private Circle buildingImage;
    static private double startX, startY;
    static private Boolean inBuilding = false;
    public Button nextTurn;

    @FXML
    private StackPane stackPane;
    @FXML
    private ToolBar mainToolBar;
    @FXML
    private ToolBar buildingToolBar;
    @FXML
    private ToolBar troopToolBar;
    @FXML
    private Button backButton;

    //Building ToolBar
    @FXML
    private Button nextBuilding;
    @FXML
    private Button prevBuilding;
    @FXML
    private Button firstBuilding;
    @FXML
    private Button secondBuilding;
    @FXML
    private Button thirdBuilding;
    public int middleBuildingIndex = 1;
    public BuildingUI selectedBuilding = null;

    //Troop Toolbar
    @FXML
    private Button nextTroop;
    @FXML
    private Button prevTroop;
    @FXML
    private Button firstTroop;
    @FXML
    private Button secondTroop;
    @FXML
    private Button thirdTroop;
    public int middleTroopIndex = 1;
    public boolean movingTroop = false;
    public boolean attackingTroop = false;

    //Cell Details
    @FXML
    private AnchorPane cellDetails;
    @FXML
    private Text cellBuilding;
    @FXML
    private Text cellCoordinates;
    @FXML
    private Text cellTroops;
    @FXML
    private Text cellType;
    @FXML
    private Button modifyTileButton;

    //Cell Info
    @FXML
    public AnchorPane cellInfo;
    @FXML
    public Text cellInfoText;

    //Troops Info
    @FXML
    public AnchorPane troopDetail;
    @FXML
    public Text stanceText;
    @FXML
    public Button defenciveButton;
    @FXML
    public Button offenciveButton;
    @FXML
    public Button standingButton;
    @FXML
    public Button moveButton;
    @FXML
    public Button attackButton;

    //Government
    @FXML
    public AnchorPane governmentToolBar;
    @FXML
    public Text scribeReport;
    @FXML
    public Text populationText;
    @FXML
    public Text popularityText;
    @FXML
    public Text goldText;
    @FXML
    public Text resourcesText;
    @FXML
    public Button governmentButton;

    //Modify Tile
    @FXML
    public AnchorPane modifyTileToolBar;
    @FXML
    public Button dustTile, grassTile, meadowTile, stoneTile, ironTile, riverTile, beachTile, seaTile;
    //Popularity Panel
    @FXML
    public AnchorPane popularityPanel;
    @FXML
    public Button popularityPanelButton;
    @FXML
    public Slider taxSlider;
    @FXML
    public Slider foodSlider;
    @FXML
    public Slider fearSlider;
    @FXML
    public Text taxText, foodText, fearText;

    int selectedTileX, selectedTileY;

    @FXML
    public Button nextTurnButton;

    public Map gameMap;
    public static Government government;
    public Scene scene;

    ArrayList<ImageView> soldiers = new ArrayList<>();
    ArrayList<ImageView> fires = new ArrayList<>();
    ArrayList<ImageView> sicks = new ArrayList<>();

    public static String Clipboard = null;

    @Override
    public void Awake() throws IOException {
        instance = this;

        gameMap = new Map();

        gameMap.tiles[100][100].tileType = "Grass";
        gameMap.tiles[100][101].tileType = "Grass";

        //Database.InitializeDatabase();
        government = GameMenuController.currentGovernment;
        GameMenuController.gameMap = gameMap;

        System.out.println(GameMenuController.currentGovernment);

        gridPane = createGridPane();
        stackPane.getChildren().add(0, gridPane);

        buildingToolBar.setVisible(false);
        nextTurnButton.setOnMouseClicked(event -> {
            try {
                NextTurn();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        nextBuilding.setOnMouseClicked(event -> {
            try {
                NextBuilding();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        prevBuilding.setOnMouseClicked(event -> {
            try {
                PreviousBuilding();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        ImageView imageOne = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex - 1).building.pictureName).openStream()));
        ImageView imageTwo = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex).building.pictureName).openStream()));
        ImageView imageThree = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex + 1).building.pictureName).openStream()));

        imageOne.setFitHeight(110); imageOne.setFitWidth(120);
        imageTwo.setFitHeight(110); imageTwo.setFitWidth(120);
        imageThree.setFitHeight(110); imageThree.setFitWidth(120);

        firstBuilding.setGraphic(imageOne);
        secondBuilding.setGraphic(imageTwo);
        thirdBuilding.setGraphic(imageThree);

        firstBuilding.setOnMouseClicked(event -> {
            try {
                Build(middleBuildingIndex - 1);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        secondBuilding.setOnMouseClicked(event -> {
            try {
                Build(middleBuildingIndex);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        thirdBuilding.setOnMouseClicked(event -> {
            try {
                Build(middleBuildingIndex + 1);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        troopToolBar.setVisible(false);

        nextTroop.setOnMouseClicked(event -> {
            try {
                NextTroop();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        prevTroop.setOnMouseClicked(event -> {
            try {
                PreviousTroop();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        firstTroop.setOnMouseClicked(event -> {
            try {
                TrainTroop(middleTroopIndex - 1);
            } catch (CloneNotSupportedException | IOException e) {
                throw new RuntimeException(e);
            }
        });
        secondTroop.setOnMouseClicked(event -> {
            try {
                TrainTroop(middleTroopIndex);
            } catch (CloneNotSupportedException | IOException e) {
                throw new RuntimeException(e);
            }
        });
        thirdTroop.setOnMouseClicked(event -> {
            try {
                TrainTroop(middleTroopIndex + 1);
            } catch (CloneNotSupportedException | IOException e) {
                throw new RuntimeException(e);
            }
        });

        backButton.setOnMouseClicked(event -> BackButtonClicked());
        backButton.setVisible(false);

        cellDetails.setVisible(false);

        prevBuilding.setVisible(false);
        prevTroop.setVisible(false);

        standingButton.setOnMouseClicked(event -> stanceButtonClicked(0));
        defenciveButton.setOnMouseClicked(event -> stanceButtonClicked(1));
        offenciveButton.setOnMouseClicked(event -> stanceButtonClicked(2));

        firstTroop.setText("");
        secondTroop.setText("");
        thirdTroop.setText("");

        moveButton.setOnMouseClicked(event -> {
            try {
                MoveTroop();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        attackButton.setOnMouseClicked(event -> {
            try {
                AttackTroop();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        governmentButton.setOnMouseClicked(event -> governmentButtonClicked());

        modifyTileButton.setOnMouseClicked(event -> ModifyTile());

        dustTile.setOnMouseClicked(event -> SetTexture("Dust"));
        grassTile.setOnMouseClicked(event -> SetTexture("Grass"));
        meadowTile.setOnMouseClicked(event -> SetTexture("Meadow"));
        stoneTile.setOnMouseClicked(event -> SetTexture("Stone"));
        ironTile.setOnMouseClicked(event -> SetTexture("Iron"));
        riverTile.setOnMouseClicked(event -> SetTexture("River"));
        beachTile.setOnMouseClicked(event -> SetTexture("Beach"));
        seaTile.setOnMouseClicked(event -> SetTexture("Sea"));

        popularityPanelButton.setOnMouseClicked(event -> OpenPopularityPanel());

        taxSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            TaxSliderChanged((Double) newValue);
        });
        foodSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            FoodSliderChanged((Double) newValue);
        });
        fearSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            FearSliderChanged((Double) newValue);
        });
    }
    public void SetTileColor(int col, int row, Rectangle rectangle){
        Tile tile = gameMap.tiles[col][row];
        String tileType = tile.tileType;

        if(tileType.equals("Dust"))  rectangle.setFill(Color.YELLOW);
        if(tileType.equals("DustRock"))  rectangle.setFill(Color.YELLOW);
        if(tileType.equals("Rock"))  rectangle.setFill(Color.DARKGREY);
        if(tileType.equals("Iron"))  rectangle.setFill(Color.RED);
        if(tileType.equals("Stone"))  rectangle.setFill(Color.LIGHTGREY);
        if(tileType.equals("Meadow"))  rectangle.setFill(Color.LIGHTGREEN);
        if(tileType.equals("MeadowDense"))  rectangle.setFill(Color.DARKGREEN);
        if(tileType.equals("Grass"))  rectangle.setFill(Color.GREEN);
        if(tileType.equals("River"))  rectangle.setFill(Color.LIGHTBLUE);
        if(tileType.equals("SmallPond"))  rectangle.setFill(Color.BLUE);
        if(tileType.equals("BigPond"))  rectangle.setFill(Color.DARKBLUE);
        if(tileType.equals("Sea"))  rectangle.setFill(Color.BLUE);
        if(tileType.equals("Beach"))  rectangle.setFill(Color.LIGHTYELLOW);
        if(tileType.equals("ShallowWater"))  rectangle.setFill(Color.LIGHTBLUE);
        if(tileType.equals("Plain"))  rectangle.setFill(Color.GREEN);
        if(tileType.equals("Oil"))  rectangle.setFill(Color.BLACK);
    }
    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(1);
        gridPane.setVgap(1);

        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                Rectangle rect = new Rectangle(CELL_SIZE, CELL_SIZE, Color.WHITE);
                rect.setStroke(Color.LIGHTGRAY);

                Text text = new Text(col + "," + row);

                text.setFill(Color.BLACK);
                text.setVisible(false);

                StackPane stackPane = new StackPane(rect, text);
                stackPane.setAlignment(Pos.CENTER);

                final int currentCol = col;
                final int currentRow = row;

                stackPane.setOnMouseEntered(event -> handleMouseEnter(currentCol, currentRow));
                stackPane.setOnMouseExited(event -> handleMouseExit(currentCol, currentRow));
                stackPane.setOnMouseClicked(event -> {
                    try {
                        handleMouseClicked(currentCol, currentRow);
                    } catch (CloneNotSupportedException | IOException e) {
                        throw new RuntimeException(e);
                    }
                });

                gridPane.add(stackPane, col, row);
                SetTileColor(col, row, rect);
            }
        }

        Circle circle = new Circle();
        circle.setRadius(10);
        circle.setVisible(false);

        gridPane.getChildren().add(circle);

        gridPane.setOnMouseMoved(event -> {
            circle.setTranslateX(event.getX() - circle.getRadius() / 2);
            circle.setTranslateY(event.getY() - circle.getRadius() * 2);
        });
        gridPane.setOnScroll(event -> {
            double deltaY = event.getDeltaY();
            double zoomFactor = 1.05;

            if (deltaY < 0) {
                zoomFactor = 1 / zoomFactor;
            }

            gridPane.setScaleX(gridPane.getScaleX() * zoomFactor);
            gridPane.setScaleY(gridPane.getScaleY() * zoomFactor);

            event.consume();
        });
        this.buildingImage = circle;
        return gridPane;
    }
    public void BuildButtonClicked(){
        //buildingImage.setVisible(true);
        //inBuilding = true;

        mainToolBar.setVisible(false);
        buildingToolBar.setVisible(true);

        backButton.setVisible(true);
    }
    public void NextBuilding() throws IOException {
        int buildingAmounts = BuildingUI.buildingUIS.size();

        middleBuildingIndex++;
        prevBuilding.setVisible(true);

        System.out.println(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex - 1).building.pictureName));
        ImageView imageOne = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex - 1).building.pictureName).openStream()));
        ImageView imageTwo = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex).building.pictureName).openStream()));
        ImageView imageThree = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex + 1).building.pictureName).openStream()));

        imageOne.setFitHeight(110); imageOne.setFitWidth(120);
        imageTwo.setFitHeight(110); imageTwo.setFitWidth(120);
        imageThree.setFitHeight(110); imageThree.setFitWidth(120);

        firstBuilding.setGraphic(imageOne);
        secondBuilding.setGraphic(imageTwo);
        thirdBuilding.setGraphic(imageThree);

        if(middleBuildingIndex + 1 == buildingAmounts - 1)
            nextBuilding.setVisible(false);
    }
    public void PreviousBuilding() throws IOException {
        middleBuildingIndex--;
        nextBuilding.setVisible(true);

        ImageView imageOne = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex - 1).building.pictureName).openStream()));
        ImageView imageTwo = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex).building.pictureName).openStream()));
        ImageView imageThree = new ImageView(new Image(getClass().getResource("/COM/" + BuildingUI.buildingUIS.get(middleBuildingIndex + 1).building.pictureName).openStream()));

        imageOne.setFitHeight(110); imageOne.setFitWidth(120);
        imageTwo.setFitHeight(110); imageTwo.setFitWidth(120);
        imageThree.setFitHeight(110); imageThree.setFitWidth(120);

        firstBuilding.setGraphic(imageOne);
        secondBuilding.setGraphic(imageTwo);
        thirdBuilding.setGraphic(imageThree);

        if(middleBuildingIndex - 1 == 0)
            prevBuilding.setVisible(false);
    }
    public void NextTroop() throws IOException {
        ArrayList<TroopUI> troopUIS;

        if(GameMenuController.selectedBuilding.getName().equals("Barracks")) troopUIS = TroopUI.christianTroops;
        else troopUIS = TroopUI.muslimTroops;

        int troopAmounts = troopUIS.size();

        middleTroopIndex++;
        prevTroop.setVisible(true);

        ImageView troopOne = new ImageView(new Image(getClass().getResource("/COM/" + troopUIS.get(middleTroopIndex - 1).troop.pictureName).openStream()));
        ImageView troopTwo = new ImageView(new Image(getClass().getResource("/COM/" + troopUIS.get(middleTroopIndex).troop.pictureName).openStream()));
        ImageView troopThree = new ImageView(new Image(getClass().getResource("/COM/" + troopUIS.get(middleTroopIndex + 1).troop.pictureName).openStream()));

        firstTroop.setGraphic(troopOne);
        secondTroop.setGraphic(troopTwo);
        thirdTroop.setGraphic(troopThree);

        if(middleTroopIndex + 1 == troopAmounts - 1)
            nextTroop.setVisible(false);
    }
    public void PreviousTroop() throws IOException {
        ArrayList<TroopUI> troopUIS;

        if(GameMenuController.selectedBuilding.getName().equals("Barracks")) troopUIS = TroopUI.christianTroops;
        else troopUIS = TroopUI.muslimTroops;

        middleTroopIndex--;
        nextTroop.setVisible(true);

        ImageView troopOne = new ImageView(new Image(getClass().getResource("/COM/" + troopUIS.get(middleTroopIndex - 1).troop.pictureName).openStream()));
        ImageView troopTwo = new ImageView(new Image(getClass().getResource("/COM/" + troopUIS.get(middleTroopIndex).troop.pictureName).openStream()));
        ImageView troopThree = new ImageView(new Image(getClass().getResource("/COM/" + troopUIS.get(middleTroopIndex + 1).troop.pictureName).openStream()));

        firstTroop.setGraphic(troopOne);
        secondTroop.setGraphic(troopTwo);
        thirdTroop.setGraphic(troopThree);

        if(middleTroopIndex - 1 == 0)
            prevTroop.setVisible(false);
    }
    public void TrainTroop(int index) throws CloneNotSupportedException, IOException {
        ArrayList<TroopUI> troopUIS;

        if(GameMenuController.selectedBuilding.getName().equals("Barracks")) troopUIS = TroopUI.christianTroops;
        else troopUIS = TroopUI.muslimTroops;

        GameMenuController.DropUnit(troopUIS.get(index).troopName, 1, GameMenuController.selectedBuilding.getX(), GameMenuController.selectedBuilding.getY());
    }
    public void Build(int index) throws IOException {
        inBuilding = true;
        //buildingImage.setVisible(true);
        selectedBuilding = BuildingUI.buildingUIS.get(index);

        Image image = new Image(getClass().getResource("/COM/build.png").openStream());
        scene.setCursor(new ImageCursor(image));
    }
    public void BackButtonClicked(){
        inBuilding = false;
        movingTroop = false;

        //buildingImage.setVisible(false);

        mainToolBar.setVisible(true);

        troopToolBar.setVisible(false);
        buildingToolBar.setVisible(false);
        troopDetail.setVisible(false);
        backButton.setVisible(false);
        governmentToolBar.setVisible(false);
        modifyTileToolBar.setVisible(false);
        popularityPanel.setVisible(false);
    }
    private void handleMouseClicked(int col, int row) throws CloneNotSupportedException, IOException {
        scene.setCursor(Cursor.DEFAULT);

        if(!inBuilding && !movingTroop && !attackingTroop) {
            cellDetails.setVisible(true);
            ShowDetails(col, row);

            selectedTileX = col;
            selectedTileY = row;
            return;
        }
        if(inBuilding) {
            //buildingImage.setVisible(false);
            inBuilding = false;

            GameMenuController.dropBuilding(col, row, selectedBuilding.buildingName);
        }
        if(movingTroop){
            GameMenuController.moveUnit(col, row);
            movingTroop = false;
        }
        if(attackingTroop){
            attackingTroop = false;

            Troop troop;
            Tile tile = gameMap.tiles[col][row];

            if(tile.troops.size() == 0)
            {
                if(GameMenuController.selectedTroop.getTroopType() != Troop.TroopType.Ranged) {
                    DisplayMessage("No Enemy in selected tile");
                    return;
                }
                GameMenuController.attack(col, row);
                return;
            }
            troop = tile.troops.get(0);
            GameMenuController.attack(troop);
        }
    }
    private void handleMouseEnter(int col, int row) {
        getRectangleByCoordinates(col,row).setFill(Color.WHITE);
    }
    private void handleMouseExit(int col, int row) {
        SetTileColor(col, row, getRectangleByCoordinates(col,row));
    }
    public void handleMousePressed(MouseEvent event) {
        startX = event.getSceneX();
        startY = event.getSceneY();
    }
    public void handleMouseDragged(MouseEvent event) {
        if (event.getButton() == MouseButton.PRIMARY) {
            double deltaX = event.getSceneX() - startX;
            double deltaY = event.getSceneY() - startY;

            double translateX = deltaX / CELL_SIZE;
            double translateY = deltaY / CELL_SIZE;

            float mouseSensitivity = 5f;
            gridPane.setTranslateX(gridPane.getTranslateX() + translateX * mouseSensitivity);
            gridPane.setTranslateY(gridPane.getTranslateY() + translateY * mouseSensitivity);

            startX = event.getSceneX();
            startY = event.getSceneY();
        }
    }
    private static Rectangle getRectangleByCoordinates(int x, int y) {
        for (Node node : gridPane.getChildren()) {
            if (node instanceof StackPane) {
                StackPane stackPane = (StackPane) node;
                int col = GridPane.getColumnIndex(stackPane);
                int row = GridPane.getRowIndex(stackPane);
                if (col == x && row == y) {
                    return (Rectangle) stackPane.getChildren().get(0);
                }
            }
        }
        return null; // Return null if the rectangle is not found
    }
    //Cell Details
    @FXML
    void closeCellDetails(ActionEvent event) {
        cellDetails.setVisible(false);
    }
    void ShowDetails(int col, int row){
        cellCoordinates.setText("Coordinates: " + col + "," + row);
        if(gameMap.tiles[col][row].building == null) cellBuilding.setText("Building: None");
        else cellBuilding.setText(gameMap.tiles[col][row].building.getName());
        cellTroops.setText("Troops: " + gameMap.tiles[col][row].troops.size());
        cellType.setText("Type: " + gameMap.tiles[col][row].tileType);
    }
    void MoveTroop() throws IOException {
        movingTroop = true;

        Image image = new Image(getClass().getResource("/COM/move.png").openStream());
        scene.setCursor(new ImageCursor(image));
    }
    void AttackTroop() throws IOException {
        attackingTroop = true;

        Image image = new Image(getClass().getResource("/COM/attack.png").openStream());
        scene.setCursor(new ImageCursor(image));
    }
    void stanceButtonClicked(int index){
        if(index == 0) GameMenuController.selectedTroop.setState(Troop.State.Standing);
        if(index == 1) GameMenuController.selectedTroop.setState(Troop.State.Defensive);
        if(index == 2) GameMenuController.selectedTroop.setState(Troop.State.Offensive);

        stanceText.setText("State: " + GameMenuController.selectedTroop.getState().toString());
    }
    void governmentButtonClicked(){
        backButton.setVisible(true);
        governmentToolBar.setVisible(true);

        populationText.setText("Population: " + government.getPopulation());

        popularityText.setText(government.getPopularity() + " (" + government.getPopularityRate() + ")");

        if(government.getPopularity() > 70) popularityText.setFill(Color.GREEN);
        else if(government.getPopularity() > 40) popularityText.setFill(Color.YELLOW);
        else popularityText.setFill(Color.RED);

        String resources = "";

        if(government.getBuildingByName("Quarry") != null) resources += "Stone, ";
        if(government.getBuildingByName("IronMine") != null) resources += "Iron,";
        if(government.getBuildingByName("OilPitch") != null) resources += "Oil,";

        if(resources.length() != 0) resources = resources.substring(0, resources.length() - 1);
        resourcesText.setText("Resources: " + resources);

        Storage Stockpile = (Storage) government.getBuildingByName("Stockpile");

        if(Stockpile == null){
            goldText.setText("Gold: 0");
            return;
        }

        goldText.setText("Gold: " + Stockpile.getInventory().getAmount("Gold"));
    }

    //Modify Toolbar
    public void ModifyTile(){
        modifyTileToolBar.setVisible(true);
        backButton.setVisible(true);
    }
    public void SetTexture(String Type){
        int x = selectedTileX;
        int y = selectedTileY;

        if(gameMap.tiles[x][y].building != null || gameMap.tiles[x][y].tree != null || gameMap.tiles[x][y].rock != null || gameMap.tiles[x][y].troops.size() != 0){
            DisplayMessage("Tile is not clear!");
            return;
        }
        gameMap.tiles[x][y].tileType = Type;

        MiniMapController.SetTileColor(x, y, MiniMapController.getRectangleByCoordinates(x, y));
        SetTileColor(x, y, getRectangleByCoordinates(x, y));
    }
    //Popularity Panel
    public void OpenPopularityPanel(){
        popularityPanel.setVisible(true);
        backButton.setVisible(true);
    }
    public void TaxSliderChanged(double newValue){
        int newValueInt = (int) newValue;

        government.setTaxRate(newValueInt);
        taxText.setText("Tax Rate: " + newValueInt + "(" + government.popularityOfTaxRate() + ")");
    }
    public void FoodSliderChanged(double newValue){
        int newValueInt = (int) newValue;

        government.setFoodRate(newValueInt);
        foodText.setText("Food Rate: " + newValueInt + "(" + government.popularityOfFoodRate() + ")");
    }
    public void FearSliderChanged(double newValue){
        int newValueInt = (int) newValue;

        government.setFearRate(newValueInt);
        fearText.setText("Fear Rate: " + newValueInt + "(" + -newValueInt + ")");
    }

    public static void onBuildingHover(Building building){
        instance.cellInfo.setVisible(true);
        instance.cellInfoText.setText(building.getName());
    }
    public static void onBuildingHoverExit(){
        instance.cellInfo.setVisible(false);
    }
    public static void onBuildingClicked(int col, int row) throws IOException {
        Building building = instance.gameMap.tiles[col][row].building;
        GameMenuController.selectBuilding(col, row);

        if(building instanceof Barracks){
            instance.troopToolBar.setVisible(true);
            instance.backButton.setVisible(true);
            instance.mainToolBar.setVisible(false);

            ArrayList<TroopUI> troopUIS;

            if(GameMenuController.selectedBuilding.getName().equals("Barracks"))
                troopUIS = TroopUI.christianTroops;
            else
                troopUIS = TroopUI.muslimTroops;

            ImageView troopOne = new ImageView(new Image(instance.getClass().getResource("/COM/" + troopUIS.get(instance.middleTroopIndex - 1).troop.pictureName).openStream()));
            ImageView troopTwo = new ImageView(new Image(instance.getClass().getResource("/COM/" + troopUIS.get(instance.middleTroopIndex).troop.pictureName).openStream()));
            ImageView troopThree = new ImageView(new Image(instance.getClass().getResource("/COM/" + troopUIS.get(instance.middleTroopIndex + 1).troop.pictureName).openStream()));

            instance.firstTroop.setGraphic(troopOne);
            instance.secondTroop.setGraphic(troopTwo);
            instance.thirdTroop.setGraphic(troopThree);
        }
    }
    public static void onTroopHover(Troop troop){
        instance.cellInfo.setVisible(true);
        instance.cellInfoText.setText(troop.getTroopName());
    }
    public static void onTroopHoverExit(){
        instance.cellInfo.setVisible(false);
    }
    public static void onTroopClicked(int col, int row){
        GameMenuController.selectUnit(col, row);

        instance.backButton.setVisible(true);
        instance.troopDetail.setVisible(true);
    }

    //Controller Received Events
    public static void dropBuilding(Building clonedBuilding, int col, int row) throws IOException {
        /*Circle circle = new Circle();
        circle.setRadius(10);
        circle.setVisible(true);

        circle.setFill(Color.RED);

        circle.setOnMouseEntered(event -> onBuildingHover(clonedBuilding));
        circle.setOnMouseExited(event -> onBuildingHoverExit());
        circle.setOnMouseClicked(event -> onBuildingClicked(col, row));*/

        ImageView imageView = new ImageView(new Image(instance.getClass().getResource("/COM/" + clonedBuilding.pictureName).openStream()));
        imageView.setFitHeight(50);
        imageView.setFitWidth(50);

        imageView.setOnMouseEntered(event -> onBuildingHover(clonedBuilding));
        imageView.setOnMouseExited(event -> onBuildingHoverExit());
        imageView.setOnMouseClicked(event -> {
            try {
                onBuildingClicked(col, row);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        gridPane.add(imageView, col, row);

        Rectangle rect = getRectangleByCoordinates(col, row);
        if (rect == null) return;

        imageView.setTranslateX(rect.getWidth() / 2 - 25);
        imageView.setTranslateY(0);
    }
    public static void createUnit(Troop clonedTroop, int col, int row) throws IOException {
        /*Rectangle rectangle = new Rectangle();
        rectangle.setHeight(10);
        rectangle.setWidth(10);
        rectangle.setVisible(true);

        rectangle.setFill(Color.BLUE);

        rectangle.setOnMouseEntered(event -> onTroopHover(clonedTroop));
        rectangle.setOnMouseExited(event -> onTroopHoverExit());
        rectangle.setOnMouseClicked(event -> onTroopClicked(col, row));*/

        ImageView troop = new ImageView(new Image(instance.getClass().getResource("/COM/" + clonedTroop.pictureName).openStream()));
        troop.setVisible(true);
        troop.setFitHeight(40);
        troop.setFitWidth(20);

        troop.setOnMouseEntered(event -> onTroopHover(clonedTroop));
        troop.setOnMouseExited(event -> onTroopHoverExit());
        troop.setOnMouseClicked(event -> onTroopClicked(col, row));

        gridPane.add(troop, col, row);

        Rectangle rect = getRectangleByCoordinates(col, row);
        if (rect == null) return;

        troop.setTranslateX(rect.getWidth() / 2 - 10);
        troop.setTranslateY(0);

        instance.soldiers.add(troop);
    }
    public static void SelectTroop(Troop troop){
        instance.backButton.setVisible(true);
        instance.troopDetail.setVisible(true);
        instance.stanceText.setText("State: " + troop.getState().toString());
    }
    public static void DisplayMessage(String message){
        instance.scribeReport.setText(message);

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.seconds(3), event -> {
                    instance.scribeReport.setText(""); // Clear the text after the delay
                })
        );
        timeline.play();
    }
    public void openShop() throws Exception {
        new ShopMenu().start(new Stage());
    }
    public void openTrade() throws Exception {
        new TradeMenu().start(new Stage());
    }

    public void NextTurn() throws IOException {
        for(ImageView fire : fires){
            System.out.println("Clearing Fire");
            gridPane.getChildren().remove(fire);
        }

        GameMenuController.nextTurn();
        government = GameMenuController.currentGovernment;

        for(ImageView soldier : soldiers){
            gridPane.getChildren().remove(soldier);
        }
        for(ImageView sick : sicks){
            gridPane.getChildren().remove(sick);
        }
        ArrayList<Troop> troops = gameMap.allTroops();

        for(Troop troop : troops){
            HelloController.createUnit(troop, troop.getX(), troop.getY());
        }

        Building farm = null;
        for (Building building : GameMenuController.currentGovernment.getBuildings()) {
            if(building.getBuildingType().equals(Building.BuildingType.farms)) {
                farm = building;
                break;
            }
        }
        if(farm == null) return;

        //Sickness Loginc
        Random rand = new Random();
        int n = rand.nextInt(5);
        n += 1;

        if(n == 1){
            System.out.println("Farm in getting sick");
            SetSickness(farm.getX(), farm.getY());
        }
    }
    public static void SetSickness(int x, int y) throws IOException {
        System.out.println("Setting Sickness");

        ImageView sickness = new ImageView(new Image(instance.getClass().getResource("/COM/redPlus.png").openStream()));
        sickness.setVisible(true);
        sickness.setFitHeight(40);
        sickness.setFitWidth(40);

        gridPane.add(sickness, x, y);

        Rectangle rect = getRectangleByCoordinates(x, y);
        if (rect == null) return;

        sickness.setTranslateX(rect.getWidth() / 2 - 20);
        sickness.setTranslateY(0);

        instance.sicks.add(sickness);
    }
    public static void SetFire(int x, int y) throws IOException {
        System.out.println("Setting Fire");

        ImageView fire = new ImageView(new Image(instance.getClass().getResource("/COM/fire.png").openStream()));
        fire.setVisible(true);
        fire.setFitHeight(60);
        fire.setFitWidth(60);

        gridPane.add(fire, x, y);

        Rectangle rect = getRectangleByCoordinates(x, y);
        if (rect == null) return;

        fire.setTranslateX(rect.getWidth() / 2 - 30);
        fire.setTranslateY(0);

        instance.fires.add(fire);
    }
    public static void Copy(){
        System.out.println("Copy");

        if(instance.cellDetails.isVisible()){
            HelloController.Clipboard = "Cell," + instance.selectedTileX + "," + instance.selectedTileY;
            return;
        }
        else{
            if(GameMenuController.selectedBuilding != null){
                HelloController.Clipboard = "Building," + GameMenuController.selectedBuilding.getName() + "," + GameMenuController.selectedBuilding.getX() + "," + GameMenuController.selectedBuilding.getY();
                return;
            }
        }
        System.out.println("Can't Copy");
    }
    public static void Paste() throws IOException, CloneNotSupportedException {
        if(HelloController.Clipboard == null) return;
        System.out.println(HelloController.Clipboard);

        String[] clipboards = HelloController.Clipboard.split(",");
        Tile newTile = instance.gameMap.tiles[instance.selectedTileY][instance.selectedTileY];

        if(clipboards.length == 3){
            System.out.println("Copying Cell");
            Tile oldTile = instance.gameMap.tiles[Integer.parseInt(clipboards[1])][Integer.parseInt(clipboards[2])];
            instance.SetTexture(oldTile.tileType);
        }
        if(clipboards.length == 4){
            System.out.println("Copying Building");
            Tile oldTile = instance.gameMap.tiles[Integer.parseInt(clipboards[2])][Integer.parseInt(clipboards[3])];
            GameMenuController.dropBuilding(instance.selectedTileX, instance.selectedTileY, clipboards[1]);
        }
        HelloController.Clipboard = null;
    }
}