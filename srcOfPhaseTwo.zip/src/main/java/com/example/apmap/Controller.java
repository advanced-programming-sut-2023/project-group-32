package com.example.apmap;

import java.io.IOException;

public abstract class Controller {
    abstract void Awake() throws IOException;
}
