package com.example.apmap;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import model.Map;
import model.Tile;

import java.io.IOException;

public class MiniMapController {
    public static MiniMapController instance;
    private static final int GRID_SIZE = 200;
    private static final int VISIBLE_SIZE = 10;
    private static final int CELL_SIZE = 20;

    public Scene scene;

    @FXML
    private StackPane stackPane;
    private GridPane gridPane;

    public void Awake(){
        if(instance == null) {
            instance = this;
        }
        else{
            return;
        }
        gridPane = createGridPane();
        stackPane.getChildren().add(gridPane);
    }
    public static void SetTileColor(int col, int row, Rectangle rectangle){
        Tile tile = HelloController.instance.gameMap.tiles[col][row];
        String tileType = tile.tileType;

        if(tileType.equals("Dust"))  rectangle.setFill(Color.YELLOW);
        if(tileType.equals("DustRock"))  rectangle.setFill(Color.YELLOW);
        if(tileType.equals("Rock"))  rectangle.setFill(Color.DARKGREY);
        if(tileType.equals("Iron"))  rectangle.setFill(Color.RED);
        if(tileType.equals("Stone"))  rectangle.setFill(Color.LIGHTGREY);
        if(tileType.equals("Meadow"))  rectangle.setFill(Color.LIGHTGREEN);
        if(tileType.equals("MeadowDense"))  rectangle.setFill(Color.DARKGREEN);
        if(tileType.equals("Grass"))  rectangle.setFill(Color.GREEN);
        if(tileType.equals("River"))  rectangle.setFill(Color.LIGHTBLUE);
        if(tileType.equals("SmallPond"))  rectangle.setFill(Color.BLUE);
        if(tileType.equals("BigPond"))  rectangle.setFill(Color.DARKBLUE);
        if(tileType.equals("Sea"))  rectangle.setFill(Color.BLUE);
        if(tileType.equals("Beach"))  rectangle.setFill(Color.LIGHTYELLOW);
        if(tileType.equals("ShallowWater"))  rectangle.setFill(Color.LIGHTBLUE);
        if(tileType.equals("Plain"))  rectangle.setFill(Color.GREEN);
        if(tileType.equals("Oil"))  rectangle.setFill(Color.BLACK);
    }
    private GridPane createGridPane() {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(1);
        gridPane.setVgap(1);

        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                Rectangle rect = new Rectangle(CELL_SIZE, CELL_SIZE, Color.WHITE);
                rect.setStroke(Color.LIGHTGRAY);

                Text text = new Text(col + "," + row);

                text.setFill(Color.BLACK);
                text.setVisible(false);

                //StackPane stackPane = new StackPane(rect, text);
                //stackPane.setAlignment(Pos.CENTER);

                final int currentCol = col;
                final int currentRow = row;

                gridPane.add(rect, col, row);
                SetTileColor(col, row, rect);
            }
        }
        gridPane.setOnScroll(event -> {
            double deltaY = event.getDeltaY();
            double zoomFactor = 1.05;

            if (deltaY < 0) {
                zoomFactor = 1 / zoomFactor;
            }

            gridPane.setScaleX(gridPane.getScaleX() * zoomFactor);
            gridPane.setScaleY(gridPane.getScaleY() * zoomFactor);

            event.consume();
        });
        return gridPane;
    }
    public static Rectangle getRectangleByCoordinates(int x, int y) {
        for (Node node : instance.gridPane.getChildren()) {
            Rectangle rectangle = (Rectangle) node;
            int col = GridPane.getColumnIndex(rectangle);
            int row = GridPane.getRowIndex(rectangle);
            if (col == x && row == y) {
                return rectangle;
            }
        }
        return null; // Return null if the rectangle is not found
    }
}