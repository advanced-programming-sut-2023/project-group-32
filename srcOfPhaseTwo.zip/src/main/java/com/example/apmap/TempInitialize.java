package com.example.apmap;

public class TempInitialize {
}
