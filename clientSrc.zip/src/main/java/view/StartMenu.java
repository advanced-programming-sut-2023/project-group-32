package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class StartMenu extends Application implements Runnable {
    private static Stage stage;
    public static void main(String[] args) throws InterruptedException, IOException, CloneNotSupportedException {
        StartMenu startMenu = new StartMenu();
        Thread thread = new Thread(startMenu);
        thread.start();
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        StartMenu.stage=stage;
        URL url = StartMenu.class.getResource("/FXML/main.fxml");
        BorderPane borderPane = FXMLLoader.load(url);
        Scene scene = new Scene(borderPane);
        stage.setScene(scene);
        stage.show();
    }

    public static Stage getStage() {
        return stage;
    }

    @Override
    public void run() {
        Client client = null;
        try {
            client = new Client("localhost", 8080);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
