package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;


import java.net.URL;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class LoginMenu extends Application {
    public static Stage stage;
    public static Pane pane;
    public static AtomicInteger captcha;
    @Override
    public void start(Stage stage) throws Exception {
        LoginMenu.stage = stage;
        URL url = StartMenu.class.getResource("/FXML/loginMenu.fxml");
        pane = FXMLLoader.load(url);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
    }

}
