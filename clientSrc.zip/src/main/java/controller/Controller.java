package controller;

public class Controller {
    public static boolean checkPassword(String password){
        return password.equals("random") || (password.length() >= 6 && password.matches(".*[a-z].*") && password.matches(".*[A-Z].*") &&
                password.matches(".*[0-9].*") && password.matches(".*[^a-zA-Z0-9].*"));
    }
}
