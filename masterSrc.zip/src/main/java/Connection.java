import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.Math.min;

public class Connection extends Thread{
    Socket socket;
    final DataInputStream dataInputStream;
    final DataOutputStream dataOutputStream;
    public static int port = 0;
    final Set<String> subscribtionSet = new HashSet<>();

    public Connection(Socket socket) throws IOException {
        if(port == 0){
            port = socket.getPort();
        }
        connections.add(this);
        System.out.println("New connection form: " + socket.getInetAddress() + ":" + socket.getPort());
        this.socket = socket;
        this.dataInputStream = new DataInputStream(socket.getInputStream());
        this.dataOutputStream = new DataOutputStream(socket.getOutputStream());
    }

    @Override
    public synchronized void run() {
        Scanner scanner = new Scanner(System.in);
        Input input = new Input(dataInputStream);
        input.start();
        try {
            while (true){
                handel(scanner);
            }
        } catch (IOException e) {
            System.out.println("Connection " + socket.getInetAddress() + ":" + socket.getPort() + " lost!");
        }
    }


    private synchronized void handel(Scanner scanner) throws IOException {
        while (true){
            String data = scanner.nextLine();
            dataOutputStream.writeUTF(data);
        }
    }
}
