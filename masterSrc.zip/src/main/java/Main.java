public class Main {
    public static void main(String[] args) {
        Master master = new Master(8080);
    }
}